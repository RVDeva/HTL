public void searchByLeadHistoryStatusCreated(ActionRequest actionRequest,ActionResponse actionResponse) throws IOException, WindowStateException, SystemException, PortalException
        {

            String searchResult = ParamUtil.getString(actionRequest, "searchResult");

            DynamicQuery dquery = DynamicQueryFactoryUtil.forClass(CompanyDetails.class);
            Criterion criterion = null;

            criterion = RestrictionsFactoryUtil.like ("salesCompanyName","%"+searchResult+"%");

            criterion = RestrictionsFactoryUtil.or(criterion, RestrictionsFactoryUtil.like("salesStatus", "%"+searchResult+"%"));
            criterion = RestrictionsFactoryUtil.or(criterion, RestrictionsFactoryUtil.like("salesHistory", "%"+searchResult+"%"));

            criterion = RestrictionsFactoryUtil.and(criterion, RestrictionsFactoryUtil.eq("convertedToCustomer", false));

            dquery.add(criterion);

            List<CompanyDetails> requestList = null;

            try {
                requestList = CompanyDetailsLocalServiceUtil.dynamicQuery(dquery);
            } catch (SystemException e) {
                e.printStackTrace();
            }

            PortletSession sess = actionRequest.getPortletSession();

            sess.setAttribute("filterDetails",requestList);
            actionResponse.setRenderParameter("jspPage", "/html/jgclientbusinessdevelopment/viewLead.jsp");
        }