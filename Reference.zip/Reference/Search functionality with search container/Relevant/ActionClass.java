	
	/* search skill based on capability */

	public void searchSkillCapability(ActionRequest actionRequest,
			ActionResponse actionResponse) {
	
		List<Skill> skillList = HNSkillCapabilityManagement.getBySkillOrCapability(ParamUtil.getString(actionRequest,
				"industry"),ParamUtil.getString(actionRequest,
						"capability"),ParamUtil.getString(actionRequest,
								"Skill"));
		
		PortletSession sess = actionRequest.getPortletSession();
		sess.setAttribute("searchSkillList", skillList);
		
		PortalUtil.copyRequestParameters(actionRequest, actionResponse);

		actionResponse.setRenderParameter("jspPage",
				"/html/hnskillcapabilitymanagement/viewSkillCapability.jsp");

	}
	
	
	public static List<Skill> getBySkillOrCapability(String industry,String capabilityType,String skillType) {
		
		List<Skill> list=new ArrayList<Skill>();
		
		try {
			
			DynamicQuery dynamicQuery = DynamicQueryFactoryUtil
					.forClass(Skill.class);
			
			if(DoValidation.IsString(industry))
				dynamicQuery.add(RestrictionsFactoryUtil.eq("industryCategoryType", industry));
			
			if(DoValidation.IsString(capabilityType))
				dynamicQuery.add(RestrictionsFactoryUtil.eq("capabilityType", capabilityType));
			
			if(DoValidation.IsString(skillType))
				dynamicQuery.add(RestrictionsFactoryUtil.eq("skillType", skillType));
			
			
			list=SkillLocalServiceUtil.dynamicQuery(dynamicQuery);
			
			
		} catch (Exception e) {
		}
		
		return list;
		
		
	}
	
	
	/* remove searchSkilCapability */

	public void removeSkillCapabilitySession(ActionRequest request,
			ActionResponse response) throws SystemException {

		PortletSession searchsession = request.getPortletSession();
		searchsession.setAttribute("searchSkillList", null);

		response.setRenderParameter("jspPage",
				"/html/hnskillcapabilitymanagement/viewSkillCapability.jsp");
	}
}

