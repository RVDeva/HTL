package com.al.leypartslan.services;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.json.JSONException;
import org.json.JSONObject;

import com.al.leypartslan.connection.Connection;
import com.al.leypartslan.resources.Converter;
import com.al.leypartslan.resources.LeypartsDTO;
import com.al.leypartslan.resources.Leyparts_Bapis;
import com.sap.conn.jco.JCoException;

@Path("/Services")
public class Services {
	
	@POST
	@Path("/Login")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response login(@Context HttpServletRequest request,LeypartsDTO obj) throws JSONException, JCoException {
		
		JSONObject data = new JSONObject();
		Connection.connectionPropertiesForLeyparts(Connection.SAP_userName, Connection.SAP_password);
		Converter.role_properties_path=request.getServletContext().getRealPath("/roles.properties");
		if(Connection.login(Connection.DESTINATION_NAME_FOR_LEAVE1)) {
			data = Leyparts_Bapis.userRole(obj);
		} else {
			data.put("status", "E");
			data.put("message", "Error in SAP Connection");
		}
		
		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(data.toString()).build();
		
	}
	
	@POST
	@Path("/GetCreditLimit")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getCreditLimit(LeypartsDTO obj) throws JSONException, JCoException {
		
		JSONObject data = new JSONObject();
		Connection.connectionPropertiesForLeyparts(Connection.SAP_userName, Connection.SAP_password);
		
		if(Connection.login(Connection.DESTINATION_NAME_FOR_LEAVE1)) {
			data = Leyparts_Bapis.displayCreditLimit(obj);
		} else {
			data.put("status", "E");
			data.put("message", "Error in SAP Connection");
		}
		
		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(data.toString()).build();
		
	}
	
	@POST
	@Path("/GetDealerDetails")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getDealerDetails(LeypartsDTO obj) throws JSONException, JCoException {
		
		JSONObject data = new JSONObject();
		Connection.connectionPropertiesForLeyparts(Connection.SAP_userName, Connection.SAP_password);
		
		if(Connection.login(Connection.DESTINATION_NAME_FOR_LEAVE1)) {
			data = Leyparts_Bapis.getDealerDetails(obj);
		} else {
			data.put("status", "E");
			data.put("message", "Error in SAP Connection");
		}
		
		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(data.toString()).build();
		
	}
	
	@POST
	@Path("/GetOrderDetails")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getOrderDetails(LeypartsDTO obj) throws JSONException, JCoException {
		
		JSONObject data = new JSONObject();
		Connection.connectionPropertiesForLeyparts(Connection.SAP_userName, Connection.SAP_password);
		
		if(Connection.login(Connection.DESTINATION_NAME_FOR_LEAVE1)) {
			data = Leyparts_Bapis.orderDetails(obj);
		} else {
			data.put("status", "E");
			data.put("message", "Error in SAP Connection");
		}
		
		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(data.toString()).build();
		
	}
	
	@POST
	@Path("/OrderDispatch")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getOrderDispatch(LeypartsDTO obj) throws JSONException, JCoException {
		
		JSONObject data = new JSONObject();
		Connection.connectionPropertiesForLeyparts(Connection.SAP_userName, Connection.SAP_password);
		
		if(Connection.login(Connection.DESTINATION_NAME_FOR_LEAVE1)) {
			data = Leyparts_Bapis.orderDispatch(obj);
		} else {
			data.put("status", "E");
			data.put("message", "Error in SAP Connection");
		}
		
		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(data.toString()).build();
		
	}
	
	@POST
	@Path("/OrderHeader")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getOrderHeader(LeypartsDTO obj) throws JSONException, JCoException {
		
		JSONObject data = new JSONObject();
		Connection.connectionPropertiesForLeyparts(Connection.SAP_userName, Connection.SAP_password);
		
		if(Connection.login(Connection.DESTINATION_NAME_FOR_LEAVE1)) {
			data = Leyparts_Bapis.orderHeader(obj);
		} else {
			data.put("status", "E");
			data.put("message", "Error in SAP Connection");
		}
		
		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(data.toString()).build();
		
	}
	
	@POST
	@Path("/GetPartsStock")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getPartsStock(LeypartsDTO obj) throws JSONException, JCoException {
		
		JSONObject data = new JSONObject();
		Connection.connectionPropertiesForLeyparts(Connection.SAP_userName, Connection.SAP_password);
		
		if(Connection.login(Connection.DESTINATION_NAME_FOR_LEAVE1)) {
			data = Leyparts_Bapis.getPartsStock(obj);
		} else {
			data.put("status", "E");
			data.put("message", "Error in SAP Connection");
		}
		
		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(data.toString()).build();
		
	}
	
	@POST
	@Path("/GetAlternateMaterialNo")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getAlternateMaterialNo(LeypartsDTO obj) throws JSONException, JCoException {
		
		JSONObject data = new JSONObject();
		Connection.connectionPropertiesForLeyparts(Connection.SAP_userName, Connection.SAP_password);
		
		if(Connection.login(Connection.DESTINATION_NAME_FOR_LEAVE1)) {
			data = Leyparts_Bapis.getAlternateMaterialNo(obj);
		} else {
			data.put("status", "E");
			data.put("message", "Error in SAP Connection");
		}
		
		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(data.toString()).build();
		
	}
	
	@POST
	@Path("/GetPlantDetails")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getPlantDetails() throws JSONException, JCoException {
		
		JSONObject data = new JSONObject();
		Connection.connectionPropertiesForLeyparts(Connection.SAP_userName, Connection.SAP_password);
		
		if(Connection.login(Connection.DESTINATION_NAME_FOR_LEAVE1)) {
			data = Leyparts_Bapis.getPlantDetails();
		} else {
			data.put("status", "E");
			data.put("message", "Error in SAP Connection");
		}
		
		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(data.toString()).build();
		
	}
	
	@POST
	@Path("/GetMindDetails")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getMindDetails(LeypartsDTO obj) throws JSONException, JCoException {
		
		JSONObject data = new JSONObject();
		Connection.connectionPropertiesForLeyparts(Connection.SAP_userName, Connection.SAP_password);
		
		if(Connection.login(Connection.DESTINATION_NAME_FOR_LEAVE1)) {
			data = Leyparts_Bapis.getMindDetails(obj);
		} else {
			data.put("status", "E");
			data.put("message", "Error in SAP Connection");
		}
		
		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(data.toString()).build();
		
	}
	
	@POST
	@Path("/GetPlantMindDetails")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getPlantMindDetails() throws JSONException, JCoException {
		
		JSONObject data = new JSONObject();
		Connection.connectionPropertiesForLeyparts(Connection.SAP_userName, Connection.SAP_password);
		
		if(Connection.login(Connection.DESTINATION_NAME_FOR_LEAVE1)) {
			data = Leyparts_Bapis.getPlantMindDetails();
		} else {
			data.put("status", "E");
			data.put("message", "Error in SAP Connection");
		}
		
		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(data.toString()).build();
		
	}
	
	@POST
	@Path("/GetMITRDetails")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response eMITR_details(LeypartsDTO obj) throws JSONException, JCoException {
		
		JSONObject data = new JSONObject();
		Connection.connectionPropertiesForLeyparts(Connection.SAP_userName, Connection.SAP_password);
		
		if(Connection.login(Connection.DESTINATION_NAME_FOR_LEAVE1)) {
			data = Leyparts_Bapis.eMITR_details(obj);
		} else {
			data.put("status", "E");
			data.put("message", "Error in SAP Connection");
		}
		
		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(data.toString()).build();
		
	}
	
	@POST
	@Path("/GetPriceDetails")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getPriceDetails(LeypartsDTO obj) throws JSONException, JCoException {
		
		JSONObject data = new JSONObject();
		Connection.connectionPropertiesForLeyparts(Connection.SAP_userName, Connection.SAP_password);
		
		if(Connection.login(Connection.DESTINATION_NAME_FOR_LEAVE1)) {
			data = Leyparts_Bapis.getPriceDetails(obj);
		} else {
			data.put("status", "E");
			data.put("message", "Error in SAP Connection");
		}
		
		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(data.toString()).build();
		
	}
	
	/*@POST
	@Path("/GetCreditLimitDropdown")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response getCreditLimitDropdown(LeypartsDTO obj) throws JSONException, JCoException {
		
		JSONObject data = new JSONObject();
		Connection.connectionPropertiesForLeyparts(Connection.SAP_userName, Connection.SAP_password);
		
		if (Connection.login(Connection.DESTINATION_NAME_FOR_LEAVE1)) {
			if(obj.getCustomerNumber() != null) {
				data = Leyparts_Bapis.displayCreditLimit(obj);
			} else {
				data = Leyparts_Bapis.getDealerDetails(obj);
			}
		} else {
			data.put("status", "E");
			data.put("message", "Error in SAP Connection");
		}
		
		return Response.status(200).type(MediaType.APPLICATION_JSON).entity(data.toString()).build();
		
	}*/

}
