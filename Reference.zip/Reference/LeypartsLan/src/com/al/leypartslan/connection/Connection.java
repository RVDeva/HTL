/**
 * @author HTL_Deva
 *
 */
package com.al.leypartslan.connection;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Properties;

import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.ext.DestinationDataProvider;

public class Connection {
	
	public static String CONNECTION_TYPE = "PROD";
	
	public static String SAP_userName = "DEF_SUP_DEV"; 
	public static String SAP_password = "Welcome123";
	
	public static String DESTINATION_NAME_FOR_LEAVE1 = "ABAP_AS_LEAVE_WITHOUT_POOL";
	public static String DESTINATION_NAME_FOR_LEAVE2 = "ABAP_AS_LEAVE_WITH_POOL";
	public static String DESTINATION_NAME_FOR_CLOCK1 = "ABAP_AS_CLOCK_WITH_POOL";
	public static String DESTINATION_NAME_FOR_CLOCK2 = "ABAP_AS_CLOCK_WITHOUT_POOL";
	
	public static void createDestinationDataFile(String destinationName, Properties connectProperties) {
		
		File destConf = new File(destinationName + ".jcoDestination");
		try {
			FileOutputStream outputStream = new FileOutputStream(destConf, false);
			connectProperties.store(outputStream, "for testing!!");
			outputStream.close();
		} catch (Exception e) {
			throw new RuntimeException("Unable to create the destination files", e);
		}
		
	}
	
	public static boolean login(String destinationName) {
		
		JCoDestination destination;
		try {
			destination = JCoDestinationManager.getDestination(destinationName);
			destination.ping();
		} catch (JCoException e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
		
	}
	
	public static void connectionPropertiesForLeyparts(String userName, String password) {
		
		Properties connectProperties = new Properties();
		
		if(CONNECTION_TYPE.equalsIgnoreCase("PROD")) {
			connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, "ciPE1");
			connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, "03");
			connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, "400");
			connectProperties.setProperty(DestinationDataProvider.JCO_USER, userName);
			connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, password);
			connectProperties.setProperty(DestinationDataProvider.JCO_LANG, "en");
			createDestinationDataFile(DESTINATION_NAME_FOR_LEAVE1, connectProperties);

			connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "13");
			connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, "10");
			createDestinationDataFile(DESTINATION_NAME_FOR_LEAVE2, connectProperties);

		} else if(CONNECTION_TYPE.equalsIgnoreCase("MOCK")) {
			  connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, "10.200.223.12");
			  connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, "03"); 
			  connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, "400");
			  connectProperties.setProperty(DestinationDataProvider.JCO_USER, userName);
			  connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, password);
			  connectProperties.setProperty(DestinationDataProvider.JCO_LANG, "en"); 
			  createDestinationDataFile(DESTINATION_NAME_FOR_LEAVE1, connectProperties); 

			  connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "13");
			  connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, "10"); 
			  createDestinationDataFile(DESTINATION_NAME_FOR_LEAVE2, connectProperties);
			  
		} else if(CONNECTION_TYPE.equalsIgnoreCase("QTY")) {
			/*connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, "10.11.224.11");*/
			//connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, "10.200.116.43");
			connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, "eccq501");
			connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, "00");
			connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, "400");
			connectProperties.setProperty(DestinationDataProvider.JCO_USER, userName);
			connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, password);
			connectProperties.setProperty(DestinationDataProvider.JCO_LANG, "en");
			createDestinationDataFile(DESTINATION_NAME_FOR_LEAVE1, connectProperties);

			connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "13");
			connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, "10");
			createDestinationDataFile(DESTINATION_NAME_FOR_LEAVE2, connectProperties);
			
		} else if(CONNECTION_TYPE.equalsIgnoreCase("DEV100")) {
			//connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, "10.11.223.13");
			//connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, "10.200.113.7");
			connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, "eccd401");
			connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, "00");
			connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, "100");
			connectProperties.setProperty(DestinationDataProvider.JCO_USER,	userName);
			connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, password);
			connectProperties.setProperty(DestinationDataProvider.JCO_LANG,	"en"); 
			createDestinationDataFile(DESTINATION_NAME_FOR_LEAVE2, connectProperties); 

			connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "10");
			connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, "10"); 
			createDestinationDataFile(DESTINATION_NAME_FOR_LEAVE1, connectProperties);
			
		} else {
			connectProperties.setProperty(DestinationDataProvider.JCO_ASHOST, "10.200.116.44");
			connectProperties.setProperty(DestinationDataProvider.JCO_SYSNR, "00");
			connectProperties.setProperty(DestinationDataProvider.JCO_CLIENT, "100");
			connectProperties.setProperty(DestinationDataProvider.JCO_USER,	userName);
			connectProperties.setProperty(DestinationDataProvider.JCO_PASSWD, password);
			connectProperties.setProperty(DestinationDataProvider.JCO_LANG,	"en"); 
			createDestinationDataFile(DESTINATION_NAME_FOR_LEAVE2, connectProperties); 

			connectProperties.setProperty(DestinationDataProvider.JCO_POOL_CAPACITY, "10");
			connectProperties.setProperty(DestinationDataProvider.JCO_PEAK_LIMIT, "10"); 
			createDestinationDataFile(DESTINATION_NAME_FOR_LEAVE1, connectProperties);	
		}
		System.out.println(connectProperties);
		
	}
	
}