package com.al.leypartslan.resources;

import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.al.leypartslan.connection.Connection;
import com.sap.conn.jco.AbapException;
import com.sap.conn.jco.JCoDestination;
import com.sap.conn.jco.JCoDestinationManager;
import com.sap.conn.jco.JCoException;
import com.sap.conn.jco.JCoFunction;
import com.sap.conn.jco.JCoTable;

public class Leyparts_Bapis {
	
	public static JSONObject userRole(LeypartsDTO user) throws JCoException, JSONException {
		
		//System.out.println("--Inside login--");
		JCoDestination destination = JCoDestinationManager.getDestination(Connection.DESTINATION_NAME_FOR_LEAVE1); 
		JCoFunction function = destination.getRepository().getFunction("ZBAPI_GET_USER_ROLE");
		
		if (function == null) {
			throw new RuntimeException("ZBAPI_GET_USER_ROLE not found in SAP");
		}
		
		function.getImportParameterList().setValue("USRID", user.getUserID());
		//System.out.println("---Values---"+function.getImportParameterList());
		
		try {
			function.execute(destination);
		} catch (AbapException e) {
			e.printStackTrace();
		}
		
		JCoTable roleTable = function.getTableParameterList().getTable("LT_ROLE");
		JSONObject obj = new JSONObject();
		
		try {
			if(roleTable.getString("PARVW").equals("NO")){
				
				obj.put("STATUS", "S");
				obj.put("Partner_Function","");
				
			}else{
				
				obj.put("STATUS", "S");
				obj.put("Personnel_Number",roleTable.getString("PERNR"));
				obj.put("Partner_Function",Converter.getAccess(roleTable.getString("PARVW")));
				obj.put("Description ",roleTable.getString("VTEXT"));
				
			}
		} catch (Exception e) {
			obj.put("STATUS", "E");
			obj.put("MESSAGE", "Exception @ "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		
		return obj;
		
	}
	
	public static JSONObject displayCreditLimit(LeypartsDTO disp) throws JCoException, JSONException {
		
		//System.out.println("--Inside displayCreditLimit--");
		JCoDestination destination = JCoDestinationManager.getDestination(Connection.DESTINATION_NAME_FOR_LEAVE1);
		JCoFunction function = destination.getRepository().getFunction("ZBAPI_CREDIT_LIMIT");

		if (function == null) {
			throw new RuntimeException("ZBAPI_CREDIT_LIMIT not found in SAP");
		}

		//Inputs to BAPI
		function.getImportParameterList().setValue("KUNNR", disp.getCustomerNumber());
		function.getImportParameterList().setValue("KKBER", "2000");
		function.getImportParameterList().setValue("HIT_USRID", disp.getUserID());
		//System.out.println("---Values---"+function.getImportParameterList());
		
		try {
			function.execute(destination); //BAPI Execution
		} catch (AbapException e) {
			e.printStackTrace();
		}
		
		JCoTable creditLimitTable = function.getTableParameterList().getTable("LT_CREDIT");
		
		JSONObject itemJson = new JSONObject();
		JSONArray list = new JSONArray();
		String message = "";
		String status = "E";
		
		try {
			for (int i = 0; i < creditLimitTable.getNumRows(); i++) {
				
				creditLimitTable.setRow(i);
				//Response from BAPI
				JSONObject obj = new JSONObject();
				obj.put("Customer_Number", creditLimitTable.getString("KUNNR"));
				obj.put("Credit_Control_Area", creditLimitTable.getString("KKBER"));
				obj.put("Name1", creditLimitTable.getString("NAME1"));
				obj.put("Customer_number_of_business_partner", creditLimitTable.getString("PAYER"));
				obj.put("Customer's_credit_limit", Converter.toLakhsConvert(creditLimitTable.getString("KLIMK")));
				obj.put("Open_sales_order_credit_value", Converter.toLakhsConvert(creditLimitTable.getString("KLPRZ")));
				obj.put("Condition_value", Converter.toLakhsConvert(creditLimitTable.getString("KWERT")));
				obj.put("Current_Balance", Converter.toLakhsConvert(creditLimitTable.getString("DSOSA")));
				list.put(obj);
				
			}
			status = "S";
			message = "";
			
			if(creditLimitTable.isEmpty()) {
				itemJson.put("STATUS", "E");
				itemJson.put("MESSAGE", "No Record Found");
			} else {
				itemJson.put("STATUS", status);
				itemJson.put("MESSAGE", message);
				itemJson.put("OUTPUT", list);
			}
		} catch (Exception e) {
			itemJson.put("STATUS", "E");
			itemJson.put("MESSAGE", "Exception @ "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		
		return itemJson;
		
	}
	
	public static JSONObject getDealerDetails(LeypartsDTO details) throws JCoException, JSONException {
		
		//System.out.println("--Inside getDealerDetails--");
		HashMap< String, String> hm = new HashMap<String, String>();
		JCoDestination destination = JCoDestinationManager.getDestination(Connection.DESTINATION_NAME_FOR_LEAVE1);
		JCoFunction function = destination.getRepository().getFunction("ZBAPI_GET_HIERARCHY");
		
		if (function == null) {
			throw new RuntimeException("ZBAPI_GET_HIERARCHY not found in SAP");
		}
		
		//Input to BAPI
		function.getImportParameterList().setValue("USRID", details.getUserID());
		//System.out.println("---Values---"+function.getImportParameterList());
		
		try {
			function.execute(destination); //BAPI Execution
		} catch (AbapException e) {
			e.printStackTrace();
		}
		
		JCoTable dealerDetailsTable = function.getTableParameterList().getTable("LT_MAIN");
		JSONObject obj = new JSONObject();
		JSONArray list = new JSONArray();
		String message = "";
		String status = "E";
		//int j = 0;
		
		try {
			for (int i = 0; i < dealerDetailsTable.getNumRows(); i++) {
				
				dealerDetailsTable.setRow(i);
				//Response from BAPI
				JSONObject itemJson = new JSONObject();
				
				if(hm.get(dealerDetailsTable.getString("HIERARCHY_CODE")) == null) {
					if(dealerDetailsTable.getString("HIERARCHY_CODE") != "") {
						//String key = "DD" + (j + 1);
						itemJson.put("Hierarchy_Code", dealerDetailsTable.getString("HIERARCHY_CODE"));
						itemJson.put("Hierarchy_Name", dealerDetailsTable.getString("HIERARCHY_NAME"));
						//obj.put(key, itemJson);
						list.put(itemJson);
						hm.put(dealerDetailsTable.getString("HIERARCHY_CODE"), dealerDetailsTable.getString("HIERARCHY_NAME"));
						//j++;
					}
				}
				
			}
			status = "S";
			message = "";
			
			if(dealerDetailsTable.isEmpty()) {
				obj.put("STATUS", "E");
				obj.put("MESSAGE", "No Record Found");
			} else {
				obj.put("STATUS", status);
				obj.put("MESSAGE", message);
				obj.put("OUTPUT", list);
			}
		} catch (Exception e) {
			obj.put("STATUS", "E");
			obj.put("MESSAGE", "Exception @ "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		
		return obj;
		
	}
	
	public static JSONObject orderDetails(LeypartsDTO order) throws JCoException, JSONException {
		
		//System.out.println("--Inside orderDetails--");
		JCoDestination destination = JCoDestinationManager.getDestination(Connection.DESTINATION_NAME_FOR_LEAVE1);
		JCoFunction function = destination.getRepository().getFunction("ZBAPI_SPD_VOR_ORDER_DETAILS");
		
		if (function == null) {
			throw new RuntimeException("ZBAPI_SPD_VOR_ORDER_DETAILS not found in SAP");
		}
		
		//Inputs to BAPI
		function.getImportParameterList().setValue("VBELN", order.getSalesDocumentNumber());
		
		if(order.getMaterialNumber() != null) {
			function.getImportParameterList().setValue("MATNR", order.getMaterialNumber());
		}
		
		function.getImportParameterList().setValue("HIT_USRID", order.getUserID());
		//System.out.println("---Values---"+function.getImportParameterList());
		
		try {
			function.execute(destination); //BAPI Execution
		} catch (AbapException e) {
			e.printStackTrace();
		}
		
		JCoTable mindTableDetils = function.getTableParameterList().getTable("LT_MAIN");
		JSONObject obj = new JSONObject();
		JSONArray list = new JSONArray();
		String message = "";
		String status = "E";
		
		try {
			for (int i = 0; i < mindTableDetils.getNumRows(); i++) {
				
				mindTableDetils.setRow(i);
				//Response from BAPI
				JSONObject itemJson = new JSONObject();
				//String key = "VOR" + (i + 1);

				itemJson.put("Chasis_Number", mindTableDetils.getString("ZCHASIS_NUM"));
				itemJson.put("Engine_Number", mindTableDetils.getString("ZENG_NUM"));
				itemJson.put("Sold_to_party", mindTableDetils.getString("KUNNR"));
				itemJson.put("Name1", mindTableDetils.getString("NAME1"));
				itemJson.put("Sales_Document", mindTableDetils.getString("VBELN"));
				itemJson.put("Order_Date", mindTableDetils.getString("ERDAT"));
				
				itemJson.put("Name", mindTableDetils.getString("NAMET"));
				itemJson.put("Material_Number", mindTableDetils.getString("MATNR"));
				itemJson.put("Material_Description", mindTableDetils.getString("MAKTX"));
				
				String tmp = mindTableDetils.getString("ZMENG");
				String tmpStr = tmp.replace(".", ",");
				
				itemJson.put("O", tmpStr.split(",")[0]);
				
				tmp = mindTableDetils.getString("LFIMG");
				tmpStr = tmp.replace(".", ",");
				
				itemJson.put("D", tmpStr.split(",")[0]);
				
				tmp = mindTableDetils.getString("FKLMG");
				tmpStr = tmp.replace(".", ",");
				
				itemJson.put("I", tmpStr.split(",")[0]);
				
				tmp = mindTableDetils.getString("CANCEL_QNTY");
				tmpStr = tmp.replace(".", ",");
				
				itemJson.put("E", tmpStr.split(",")[0]);
				
				tmp = mindTableDetils.getString("BAL_QTY");
				tmpStr = tmp.replace(".", ",");
				
				itemJson.put("B", tmpStr.split(",")[0]);
				
				//obj.put(key, itemJson);
				list.put(itemJson);
				
			}
			status = "S";
			message = "";
			
			if(mindTableDetils.isEmpty()) {
				obj.put("STATUS", "E");
				obj.put("MESSAGE", "No Record Found");
			} else {
				obj.put("STATUS", status);
				obj.put("MESSAGE", message);
				obj.put("OUTPUT", list);
			}
		} catch (Exception e) {
			obj.put("STATUS", "E");
			obj.put("MESSAGE", "Exception @ "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		
		return obj;
		
	}
	
	public static JSONObject orderDispatch(LeypartsDTO patch) throws JCoException, JSONException {
		
		//System.out.println("--Inside orderDispatch--");
		JCoDestination destination = JCoDestinationManager.getDestination(Connection.DESTINATION_NAME_FOR_LEAVE1);
		JCoFunction function = destination.getRepository().getFunction("ZBAPI_SPD_VOR_DESPATCH");
		
		if (function == null) {
			throw new RuntimeException("ZBAPI_SPD_VOR_DESPATCH not found in SAP");
		}
		
		//Inputs to BAPI
		function.getImportParameterList().setValue("VBELN", patch.getSalesDocumentNumber());
		function.getImportParameterList().setValue("AUPOS", patch.getSalesDocumentItem());
		
		if(patch.getMaterialNumber() != null) {
			function.getImportParameterList().setValue("MATNR", patch.getMaterialNumber());
		}
		
		function.getImportParameterList().setValue("HIT_USRID", patch.getUserID());
		//System.out.println("---Values---"+function.getImportParameterList());
		
		try {
			function.execute(destination); //BAPI Execution
		} catch (AbapException e) {
			e.printStackTrace();
		}
		
		JCoTable vorDispatchDetils = function.getTableParameterList().getTable("LT_MAIN");
		JSONArray list = new JSONArray();
		JSONObject mindTable = new JSONObject();
		String message = "";
		String status = "E";
		
		try {
			for (int i = 0; i < vorDispatchDetils.getNumRows(); i++) {
				
				vorDispatchDetils.setRow(i);
				//Response from BAPI
				JSONObject itemJson = new JSONObject();
				
				itemJson.put("Billing_Document", vorDispatchDetils.getString("VBELN"));
				itemJson.put("Actual_Invoiced_Quantity", vorDispatchDetils.getString("FKIMG"));
				itemJson.put("Shipment_Number", vorDispatchDetils.getString("SH_TKNUM"));
				itemJson.put("GC/Way_Bill_No", vorDispatchDetils.getString("EXTI1"));
				itemJson.put("Transporter_No", vorDispatchDetils.getString("ZTRANSPORTER"));
				itemJson.put("Created_Date", vorDispatchDetils.getString("SH_ERDAT"));
				itemJson.put("Name", vorDispatchDetils.getString("WERKST"));
				itemJson.put("Material_Number", vorDispatchDetils.getString("MATNR"));
				itemJson.put("Material_Description", vorDispatchDetils.getString("MAKTX"));
				list.put(itemJson);
				
			}
			status = "S";
			message = "";
			
			if(vorDispatchDetils.isEmpty()) {
				mindTable.put("STATUS", "E");
				mindTable.put("MESSAGE", "No Record Found");
			} else {
				mindTable.put("STATUS", status);
				mindTable.put("MESSAGE", message);
				mindTable.put("OUTPUT",list);
			}
		} catch (Exception e) {
			mindTable.put("STATUS", "E");
			mindTable.put("MESSAGE", "Exception @ "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		
		return mindTable;
		
	}
	
	public static JSONObject orderHeader(LeypartsDTO head) throws JCoException, JSONException {
		
		//System.out.println("--Inside orderHeader--");
		JCoDestination destination = JCoDestinationManager.getDestination(Connection.DESTINATION_NAME_FOR_LEAVE1);
		JCoFunction function = destination.getRepository().getFunction("ZBAPI_SPD_VOR_ORDER_HEADER");
		
		if (function == null) {
			throw new RuntimeException("ZBAPI_SPD_VOR_ORDER_HEADER not found in SAP");
		}
		
		//Inputs to BAPI
		function.getImportParameterList().setValue("DAYS", "30");
		function.getImportParameterList().setValue(head.getColumnName(), head.getColumnValue());
		function.getImportParameterList().setValue("HIT_USRID", head.getUserID());
		
		if(head.getMaterialNumber() != null) {
			function.getImportParameterList().setValue("MATNR", head.getMaterialNumber());
		}
		//System.out.println("---Values---"+function.getImportParameterList());
		
		try {
			function.execute(destination); //BAPI Execution
		} catch (AbapException e) {
			e.printStackTrace();
		}
		
		JCoTable mindTableDetils = function.getTableParameterList().getTable("LT_MAIN");
		JSONObject obj = new JSONObject();
		JSONArray list = new JSONArray();
		String message = "";
		String status = "E";
		
		try {
			for (int i = 0; i < mindTableDetils.getNumRows(); i++) {
				
				mindTableDetils.setRow(i);
				//Response from BAPI
				JSONObject itemJson = new JSONObject();
				//String key = "VOR" + (i + 1);
				
				itemJson.put("Chasis_Number", mindTableDetils.getString("ZCHASIS_NUM"));
				itemJson.put("Engine_Number", mindTableDetils.getString("ZENG_NUM"));
				itemJson.put("Sold_to_party", mindTableDetils.getString("KUNNR"));
				itemJson.put("Name1", mindTableDetils.getString("NAME1"));
				itemJson.put("Sales_Document", mindTableDetils.getString("VBELN"));
				itemJson.put("VOR_Date", mindTableDetils.getString("ERDAT"));
				
				//obj.put(key, itemJson);
				list.put(itemJson);
				
			}
			status = "S";
			message = "";
			
			if(mindTableDetils.isEmpty()) {
				obj.put("STATUS", "E");
				obj.put("MESSAGE", "No Record Found");
			} else {
				obj.put("STATUS", status);
				obj.put("MESSAGE", message);
				obj.put("OUTPUT", list);
			}
		} catch (Exception e) {
			obj.put("STATUS", "E");
			obj.put("MESSAGE", "Exception @ "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		
		return obj;
		
	}
	
	public static JSONObject getPartsStock(LeypartsDTO stock) throws JCoException, JSONException {
		
		//System.out.println("--Inside getPartsStock--");
		JCoDestination destination = JCoDestinationManager.getDestination(Connection.DESTINATION_NAME_FOR_LEAVE1);
		JCoFunction function = destination.getRepository().getFunction("ZBAPI_SPD_SPARE_PARTS_STOCK");
		
		if (function == null) {
			throw new RuntimeException("ZBAPI_SPD_SPARE_PARTS_STOCK not found in SAP");
		}
		
		//Inputs to BAPI
		if(Integer.parseInt(stock.getPlant()) != 0) {
			function.getImportParameterList().setValue("WERKS", stock.getPlant());
		}
		
		function.getImportParameterList().setValue("MATNR", stock.getMaterialNumber());
		function.getImportParameterList().setValue("HIT_USRID", stock.getUserID());
		//System.out.println("---Values---"+function.getImportParameterList());
		
		try {
			function.execute(destination); //BAPI Execution
		} catch (AbapException e) {
			e.printStackTrace();
		}
		
		JCoTable partStockListTable = function.getTableParameterList().getTable("OUTPUT_DATA");
		JSONObject obj = new JSONObject();
		JSONArray list = new JSONArray();
		boolean status = false;
		
		try {
			for (int i = 0; i < partStockListTable.getNumRows(); i++) {
				
				status = true;
				partStockListTable.setRow(i);
				//Response from BAPI
				JSONObject itemJson = new JSONObject();
				//String key = "PST" + (i + 1);
				itemJson.put("Plant", partStockListTable.getString("WERKS"));
				itemJson.put("Name", partStockListTable.getString("NAME1"));
				itemJson.put("Material_Description", partStockListTable.getString("MAKTX"));
				itemJson.put("Quantity", partStockListTable.getString("VOR_ALLO"));
				itemJson.put("NON_VOR", partStockListTable.getString("NON_VOR"));
				itemJson.put("Stock_in_Inspection", partStockListTable.getString("STOCK_INS"));
				itemJson.put("Intransit_Plant", partStockListTable.getString("INTRANSIT_PLANT"));
				itemJson.put("Material_Number", partStockListTable.getString("MATNR"));
				//obj.put(key, itemJson);
				list.put(itemJson);
				
			}

			if(status) {
				obj.put("STATUS", "S");
				obj.put("MESSAGE", "");
			} else {
				obj.put("STATUS", "E");
				obj.put("MESSAGE", "No Stock Found");
			}
		} catch (Exception e) {
			obj.put("STATUS", "E");
			obj.put("MESSAGE", "Exception @ "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		
		obj.put("OUTPUT", list);
		
		return obj;
		
	}
	
	public static JSONObject getAlternateMaterialNo(LeypartsDTO matr) throws JCoException, JSONException {
		
		//System.out.println("--Inside getAlternateMaterialNo--");
		JCoDestination destination = JCoDestinationManager.getDestination(Connection.DESTINATION_NAME_FOR_LEAVE1);
		JCoFunction function = destination.getRepository().getFunction("ZBAPI_SPD_SPARE_PARTS");
		
		if (function == null) {
			throw new RuntimeException("ZBAPI_SPD_SPARE_PARTS not found in SAP");
		}
		
		//Inputs to BAPI
		function.getImportParameterList().setValue("MATNR", matr.getMaterialNumber());
		function.getImportParameterList().setValue("HIT_USRID", matr.getUserID());
		//System.out.println("---Values---"+function.getImportParameterList());
		
		try {
			function.execute(destination); //BAPI Execution
		} catch (AbapException e) {
			e.printStackTrace();
		}
		
		JCoTable materialListTable = function.getTableParameterList().getTable("OUTPUT_DATA");
		JSONObject obj = new JSONObject();
		JSONArray list = new JSONArray();
		
		try {
			if(materialListTable.getNumRows() == 0) {
				obj.put("STATUS", "E");
				obj.put("MESSAGE", "No Records Found");
			} else {
				for (int i = 0; i < materialListTable.getNumRows(); i++) {
					
					materialListTable.setRow(i);
					//Response from BAPI
					JSONObject itemJson = new JSONObject();
					//String key = "MN" + (i + 1);
					itemJson.put("Material_Number", materialListTable.getString("MATNR"));
					//obj.put(key, itemJson);
					list.put(itemJson);
					
				}
				obj.put("STATUS", "S");
				obj.put("MESSAGE", "");
				obj.put("MATERIAL", list);
			}
		} catch (Exception e) {
			obj.put("STATUS", "E");
			obj.put("MESSAGE", "Exception @ "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		
		return obj;
		
	}
	
	public static JSONObject getPlantDetails() throws JCoException, JSONException {
		
		//System.out.println("--Inside getPlantDetails--");
		JCoDestination destination = JCoDestinationManager.getDestination(Connection.DESTINATION_NAME_FOR_LEAVE1);
		JCoFunction function = destination.getRepository().getFunction("ZBAPI_SPD_GET_PLANT");
		
		if (function == null) {
			throw new RuntimeException("ZBAPI_SPD_GET_PLANT not found in SAP");
		}
		
		try {
			function.execute(destination); //BAPI Execution
		} catch (AbapException e) {
			e.printStackTrace();
		}
		
		//System.out.println(function.getTableParameterList().getTable("OUTPUT_DATA"));
		JCoTable plantListTable = function.getTableParameterList().getTable("OUTPUT_DATA");
		JSONObject obj = new JSONObject();
		JSONArray list = new JSONArray();
		String message = "";
		String status = "E";
		
		try {
			for (int i = 0; i < plantListTable.getNumRows(); i++) {
				
				plantListTable.setRow(i);
				//Response from BAPI
				JSONObject itemJson = new JSONObject();
				//String key = "PT" + (i + 1);
				itemJson.put("Plant", plantListTable.getString("WERKS"));
				itemJson.put("Name", plantListTable.getString("NAME1"));
				list.put(itemJson);
				
			}
			status = "S";
			message = "";
		} catch (Exception e) {
			message = "Exception @ "+e.getLocalizedMessage();
			e.printStackTrace();
		}
		
		obj.put("data", list);
		obj.put("status", status);
		obj.put("message", message);
		
		return obj;
		
	}
	
	public static JSONObject getMindDetails(LeypartsDTO mind) throws JCoException, JSONException {
		
		//System.out.println("--Inside getMindDetails--");
		JCoDestination destination = JCoDestinationManager.getDestination(Connection.DESTINATION_NAME_FOR_LEAVE1);
		JCoFunction function = destination.getRepository().getFunction("ZBAPI_SPD_MIND");
		
		if (function == null) {
			throw new RuntimeException("ZBAPI_SPD_MIND not found in SAP");
		}
		
		//Inputs to BAPI
		function.getImportParameterList().setValue("KUNNR", mind.getCustomerNumber());
		function.getImportParameterList().setValue("MONTHS", "5");
		
		if(Integer.parseInt(mind.getPlant())!=0) {
			function.getImportParameterList().setValue("WERKS", mind.getPlant());
		}
			
		function.getImportParameterList().setValue("HIT_USRID", mind.getUserID());
		//System.out.println("---Values---"+function.getImportParameterList());
		
		try {
			function.execute(destination); //BAPI Execution
		} catch (AbapException e) {
			e.printStackTrace();
		}
		
		JCoTable mindTableDetils = function.getTableParameterList().getTable("LT_MIND");
		JSONObject obj = new JSONObject();
		JSONArray list = new JSONArray();
		String message = "";
		String status = "E";
		
		try {
			for (int i = 0; i < mindTableDetils.getNumRows(); i++) {
				
				mindTableDetils.setRow(i);
				//Response from BAPI
				JSONObject itemJson = new JSONObject();
				//String key = "MD" + (i + 1);
				itemJson.put("Sold_to_party", mindTableDetils.getString("KUNNR"));
				itemJson.put("Name1", mindTableDetils.getString("NAME1"));
				itemJson.put("Plant", mindTableDetils.getString("WERKS"));
				itemJson.put("Name2", mindTableDetils.getString("NAME2"));
				itemJson.put("WEEK1", mindTableDetils.getString("WEEK1"));
				itemJson.put("WEEK2", mindTableDetils.getString("WEEK2"));
				itemJson.put("WEEK3", mindTableDetils.getString("WEEK3"));
				itemJson.put("WEEK4", mindTableDetils.getString("WEEK4"));
				itemJson.put("ABOVE_30DAYS", mindTableDetils.getString("ABOVE_30DAYS"));
				itemJson.put("MONTHS", mindTableDetils.getString("MONTHS"));
				itemJson.put("TOTAL", mindTableDetils.getString("TOTAL"));
				//obj.put(key, itemJson);
				list.put(itemJson);
				
			}
			status = "S";
			message = "";
			
			if(mindTableDetils.isEmpty()) {
				obj.put("STATUS", "E");
				obj.put("MESSAGE", "No Record Found");
			} else {
				obj.put("STATUS", status);
				obj.put("MESSAGE", message);
				obj.put("OUTPUT",list);
			}
		} catch (Exception e) {
			obj.put("STATUS", "E");
			obj.put("MESSAGE", "Exception @ "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		
		return obj;
		
	}
	
	public static JSONObject getPlantMindDetails() throws JCoException, JSONException {
		
		//System.out.println("--Inside getPlantMindDetails--");
		JCoDestination destination = JCoDestinationManager.getDestination(Connection.DESTINATION_NAME_FOR_LEAVE1);
		JCoFunction function = destination.getRepository().getFunction("ZBAPI_SPD_GET_PLANT_MIND");
		
		if (function == null) {
			throw new RuntimeException("ZBAPI_SPD_GET_PLANT_MIND not found in SAP");
		}
		
		try {
			function.execute(destination); //BAPI Execution
		} catch (AbapException e) {
			e.printStackTrace();
		}
		
		//System.out.println(function.getTableParameterList().getTable("OUTPUT_DATA"));
		JCoTable plantListTable = function.getTableParameterList().getTable("OUTPUT_DATA");
		JSONObject obj = new JSONObject();
		JSONArray list = new JSONArray();
		String message = "";
		String status = "E";
		
		try {
			for (int i = 0; i < plantListTable.getNumRows(); i++) {
				
				plantListTable.setRow(i);
				//Response from BAPI
				JSONObject itemJson = new JSONObject();
				//String key = "PT" + (i + 1);
				itemJson.put("Plant", plantListTable.getString("WERKS"));
				itemJson.put("Name", plantListTable.getString("NAME1"));
				//obj.put(key, itemJson);
				list.put(itemJson);
				
			}
			status = "S";
			message = "";
			
			if(plantListTable.isEmpty()) {
				obj.put("STATUS", "E");
				obj.put("MESSAGE", "No Record Found");
			} else {
				obj.put("STATUS", status);
				obj.put("MESSAGE", message);
				obj.put("OUTPUT", list);
			}
		} catch (Exception e) {
			obj.put("STATUS", "E");
			obj.put("MESSAGE", "Exception @ "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		
		return obj;
		
	}
	
	public static JSONObject eMITR_details(LeypartsDTO mitr) throws JCoException, JSONException {
		
		//System.out.println("--Inside eMITR_details--");
		JCoDestination destination = JCoDestinationManager.getDestination(Connection.DESTINATION_NAME_FOR_LEAVE1);
		JCoFunction function = destination.getRepository().getFunction("ZBAPI_SPD_EMITR");
		
		if (function == null) {
			throw new RuntimeException("ZBAPI_SPD_EMITR not found in SAP");
		}
		
		//Inputs to BAPI
		if(mitr.getMobileNumber() != null) {
			function.getImportParameterList().setValue("MOB_NUM1", mitr.getMobileNumber());
		} else {
			if(mitr.getCustomerNumber() != null && !mitr.getCustomerNumber().contains("0000")) {
				mitr.setCustomerNumber("0000"+mitr.getCustomerNumber());
			}
			function.getImportParameterList().setValue("CPCOD", mitr.getCustomerNumber());
		}
		
		function.getImportParameterList().setValue("PERIOD", mitr.getFiscalPeriod());
		function.getImportParameterList().setValue("HIT_USRID", mitr.getUserID());
		//System.out.println("---Values---"+function.getImportParameterList());
		
		try {
			function.execute(destination); //BAPI Execution
		} catch (AbapException e) {
			e.printStackTrace();
		}
		
		JCoTable eMITRTable = function.getTableParameterList().getTable("LT_MAIN");
		JSONArray list = new JSONArray();
		JSONObject itemJson = new JSONObject();
		String message = "";
		String status = "E";
		
		try {
			for (int i = 0; i < eMITRTable.getNumRows(); i++) {
				
				eMITRTable.setRow(i);
				//Response from BAPI
				JSONObject json = new JSONObject();
				json.put("Customer_Account_Number", eMITRTable.getString("CPCOD"));
				json.put("CPNAME", eMITRTable.getString("CPNAME"));
				json.put("PROPNAME", eMITRTable.getString("PROPNAME"));
				json.put("Name", eMITRTable.getString("CPTYP"));
				json.put("Customer_classification", eMITRTable.getString("CPCLASS"));
				json.put("Fiscal_Period", eMITRTable.getString("PERIOD"));
				json.put("VALUE_REDEEM", eMITRTable.getString("VALUE_REDEEM"));
				json.put("AMT_REDEEM", eMITRTable.getString("AMT_REDEEM"));
				json.put("Name2", eMITRTable.getString("NAME2"));
				json.put("MOB_NUM1", eMITRTable.getString("MOB_NUM1"));
				json.put("MOB_NUM2", eMITRTable.getString("MOB_NUM2"));
				list.put(json);
				
			}
			status = "S";
			message = "";
			
			if(eMITRTable.getNumRows()==0) {
				itemJson.put("STATUS", "E");
				itemJson.put("MESSAGE", "No Record Found");
			} else {
				itemJson.put("OUTPUT", list);
				itemJson.put("STATUS", status);
				itemJson.put("MESSAGE", message);
			}
		} catch (Exception e) {
			itemJson.put("STATUS", "E");
			itemJson.put("MESSAGE", "Exception @ "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		
		
		return itemJson;
		
	}
	
	public static JSONObject getPriceDetails(LeypartsDTO price) throws JCoException, JSONException {
		
		//System.out.println("--Inside getPriceDetails--");
		JCoDestination destination = JCoDestinationManager.getDestination(Connection.DESTINATION_NAME_FOR_LEAVE1);
		JCoFunction function = destination.getRepository().getFunction("ZBAPI_SPD_PRICE_DETAILS");
		
		if (function == null) {
			throw new RuntimeException("ZBAPI_SPD_PRICE_DETAILS not found in SAP");
		}
		
		//Inputs to BAPI
		function.getImportParameterList().setValue("MATNR", price.getMaterialNumber());
		function.getImportParameterList().setValue("HIT_USRID", price.getUserID());
		//System.out.println("---Values---"+function.getImportParameterList());
		
		try {
			function.execute(destination); //BAPI Execution
		} catch (AbapException e) {
			e.printStackTrace();
		}
		
		JCoTable pricetListTable = function.getTableParameterList().getTable("LT_PRICE");
		JSONObject obj = new JSONObject();
		JSONArray list = new JSONArray();
		String message = "";
		String status = "E";
		
		try {
			for (int i = 0; i < pricetListTable.getNumRows(); i++) {
				
				pricetListTable.setRow(i);
				//Response from BAPI
				JSONObject itemJson = new JSONObject();
				//String key = "PR" + (i + 1);
				itemJson.put("Material_Number", pricetListTable.getString("MATNR"));
				itemJson.put("Material_Description", pricetListTable.getString("MAKTX"));
				itemJson.put("Sales_unit", pricetListTable.getString("VRKME"));
				itemJson.put("Rate", pricetListTable.getString("KBETP"));
				itemJson.put("MRP_Rate", pricetListTable.getString("KBETM"));
				//obj.put(key, itemJson);
				list.put(itemJson);
				
			}
			status = "S";
			message = "";
			
			if(pricetListTable.isEmpty()) {
				obj.put("STATUS", "E");
				obj.put("MESSAGE", "No Record Found");
				
			} else {
				obj.put("STATUS", status);
				obj.put("MESSAGE", message);
				obj.put("OUTPUT", list);
			}
		} catch (Exception e) {
			obj.put("STATUS", "E");
			obj.put("MESSAGE", "Exception @ "+e.getLocalizedMessage());
			e.printStackTrace();
		}
		
		return obj;
		
	}
	
	public static void main(String args[]) {
		
		Connection.connectionPropertiesForLeyparts("DEF_SUP_DEV", "Welcome123");
		Connection.login(Connection.DESTINATION_NAME_FOR_LEAVE1);
		try {
			LeypartsDTO input = new LeypartsDTO();
			input.setUserID("73967");
			Leyparts_Bapis.getDealerDetails(input);
		} catch (JCoException e) {
			e.printStackTrace();
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
	}

}
