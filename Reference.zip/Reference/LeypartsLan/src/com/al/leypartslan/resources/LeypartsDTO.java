package com.al.leypartslan.resources;

public class LeypartsDTO {
	
	private String userID;
	private String customerNumber;
	private String materialNumber;
	private String salesDocumentNumber;
	private String salesDocumentItem;
	private String Plant;
	private String fiscalPeriod;
	private String mobileNumber;
	private String columnName;
	private String columnValue;
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getCustomerNumber() {
		return customerNumber;
	}
	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}
	public String getMaterialNumber() {
		return materialNumber;
	}
	public void setMaterialNumber(String materialNumber) {
		this.materialNumber = materialNumber;
	}
	public String getSalesDocumentNumber() {
		return salesDocumentNumber;
	}
	public void setSalesDocumentNumber(String salesDocumentNumber) {
		this.salesDocumentNumber = salesDocumentNumber;
	}
	public String getSalesDocumentItem() {
		return salesDocumentItem;
	}
	public void setSalesDocumentItem(String salesDocumentItem) {
		this.salesDocumentItem = salesDocumentItem;
	}
	public String getPlant() {
		return Plant;
	}
	public void setPlant(String plant) {
		Plant = plant;
	}
	public String getFiscalPeriod() {
		return fiscalPeriod;
	}
	public void setFiscalPeriod(String fiscalPeriod) {
		this.fiscalPeriod = fiscalPeriod;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getColumnValue() {
		return columnValue;
	}
	public void setColumnValue(String columnValue) {
		this.columnValue = columnValue;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	
}
