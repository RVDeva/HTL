package com.al.leypartslan.resources;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Converter {
	
	public static String role_properties_path = "";
	
	public static String getAccess(String key){
		String roleString = null;
		Properties prop = new Properties();
		
    	try {
    		prop.load(new FileInputStream(role_properties_path)); 
               //get the property value and print it out
    		roleString = prop.getProperty(key);
 
    	} catch (IOException ex) {
    		ex.printStackTrace();
        }
    	return roleString;
	}
	
	public static double lakhsConvert(String value) {
		
		double lakh = Double.parseDouble(value) / 100000;
		return lakh;
		
	}
	
	public static String toLakhsConvert(String digits) {
		
		String output = "";
		String digits1 = digits.replace(".", ",");
		int digitsLen = digits1.split(",")[0].length();
		
		if(digitsLen < 3) {
			if(digitsLen == 1) {
				int val = Integer.parseInt(digits1.split(",")[0]);
				System.out.println(val);
				if(val == 0) {
					output = "0";
				} else {
					output = "0.0000" + digits1.replace(",", "");
				}
			} else if(digitsLen == 2) {
				output = "0.000" + digits1.replace(",", "");
			}
		} else {
			output = lakhsConvert(digits)+"";
		}
		
		return output;
		
	}

}
