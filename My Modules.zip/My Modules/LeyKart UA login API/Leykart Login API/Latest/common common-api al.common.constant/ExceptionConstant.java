package al.common.constant;

public interface ExceptionConstant {
	public static final String CONTACT_SUPER_ADMIN_TO_ACTIVATE_YOUR_ACCOUNT = "contact.super.admin.to.activate.your.account"; 
	public static final String CONTACT_FLEET_MANAGER_TO_ACTIVATE_YOUR_ACCOUNT = "contact.fleet.manager.to.activate.your.account"; 
	public static final String DUPLICATE_LANGUAGE_CODE = "duplicate.language.code"; 
	public static final String DUPLICATE_LANGUAGE_NAME = "duplicate.language.name"; 
	public static final String MOBILE_NUMBER_MISS_MATCH = "mobile.number.miss.match";
	public static final String OTP_EXPIRED = "otp.expired";
	public static final String OTP_INACTIVE = "otp.inactive";
	public static final String OTP_MISS_MATCH = "otp.miss.match";
	public static final String SMS_CENTER_CONNECTION_REFUSED = "sms.center.connection.refused";
	public static final String DUPLICATE_SCREENNAME = "duplicate.screenname";
	public static final String DUPLICATE_EMAILADDRESS = "duplicate.emailaddress";
	public static final String NOT_ALLOWED_TO_ACCESS = "not.allowed.to.access";
	public static final String NO_SUCH_USER = "no.such.user";
	public static final String FLEET_MANAGER_DOESNOT_EXISTS = "fleet.manager.does.not.exists";
	public static final String FIRST_NAME_AND_LAST_NAME_ERROR = "first.name.last.name.cannot.be.empty";
	public static final String PANCARD_ERROR = "pancard.cannot.be.empty";
	public static final String AADHARCARD_ERROR = "aadharcard.cannot.be.empty";
	public static final String EMAIL_ID_EMPTY_ERROR = "email.id.cannot.be.empty";
	public static final String PRIMARY_MOBILE_EMPTY_ERROR = "primary.mobile.cannot.be.empty";
	public static final String PRIMARY_MOBILE_IS_BEING_USED_BY_OTHER_USER = "primary.mobile.is.being.used.by.other.registered.user";
	public static final String SECONDARY_MOBILE_EMPTY_ERROR = "secondary.mobile.cannot.be.empty";
	public static final String DRIVER_WITH_SAME_MOBILE_ALREADY_EXISTS = "D_1002";
	public static final String NO_SERVER_KEY = "no.server.key.available";
	public static final String ERROR_OCCURED_WHILE_SAVING_LOCATION = "error.occured.while.saving.location";
	public static final String INVALID_PWD = "invalid.password";
	public static final String INVALID_CURRENT_PWD = "invalid.current.password";
	public static final String NO_CHANGE_IN_PWDS = "no.change.in.current.and.new.passwords";
	public static final String SESSION_EXPIRED = "session.expired";
}
