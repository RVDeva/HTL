package al.login.rest.application;

import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.model.Company;
import com.liferay.portal.kernel.model.CompanyConstants;
import com.liferay.portal.kernel.model.Organization;
import com.liferay.portal.kernel.model.Role;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.CompanyLocalServiceUtil;
import com.liferay.portal.kernel.service.OrganizationLocalServiceUtil;
import com.liferay.portal.kernel.service.RoleLocalServiceUtil;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.Set;
import java.util.TimeZone;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.MediaType;

import org.osgi.service.component.annotations.Component;

import al.common.constant.ExceptionConstant;
import al.common.model.CompanyCode;
import al.common.service.CompanyCodeLocalServiceUtil;
import al.login.rest.pojo.LoginRest;
import al.otp.service.OTPDetailsLocalServiceUtil;
import al.pwd.aes.AES;

/**
 * @author HTL_Vasudeva
 */
@ApplicationPath("/common/usernamelogin")
@Component(immediate = true, service = Application.class)
public class LoginRestApplication extends Application {

	public Set<Object> getSingletons() {
		return Collections.<Object>singleton(this);
	}

	@GET
	@Produces("text/plain")
	public String working() {
		return "Username API!";
	}
	
	@POST
	@Path("/leykart/usernameauth")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String leykartUsernameAuth(LoginRest loginRest) {
		
		System.out.println("---Inside usernameAuth API---");
		boolean error = false;
		String errorMsg = "";
		String secret = "";
		boolean verified = false;
		User user = null;
	    String generatedPassword = null;
	    Calendar cal = Calendar.getInstance(); // creates calendar
	    DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	    dateFormat.setTimeZone(TimeZone.getTimeZone("Asia/Kolkata")); //changing timezone from GMT to IST & set timezone to SimpleDateFormat
	    
	    String incTime = null;
	    Date incDate = null;
		
		JSONObject response = JSONFactoryUtil.createJSONObject();
		
		try {
			CompanyCode code = CompanyCodeLocalServiceUtil.fetchByCode(loginRest.getCompanyCode(), true);
			Company company = CompanyLocalServiceUtil.fetchCompany(code.getCompanyId());
			
			//pwd decryption & encryption
			//AES decryption
			AES c = new AES("D4:6E:AC:3F:F0:BE"); 
			String decrStr = c.decrypt(loginRest.getPassword());
			String decrkey = c.decrypt(loginRest.getSecurityCode());
			
			Date decrDate = dateFormat.parse(decrkey);
			long reqMilliseconds = decrDate.getTime();
			
			//MD5 encryption
			generatedPassword = MD5(decrStr);
			
			//checking securitycode
			cal.setTime(new Date()); // sets calendar time/date
		    cal.add(Calendar.HOUR_OF_DAY, 1); // incrementing current time
		    incTime = dateFormat.format(cal.getTime());
		    incDate = dateFormat.parse(incTime);
		    long incMilliseconds = incDate.getTime();
		    
	        //checking security code time limit
			if(reqMilliseconds > incMilliseconds) {
				//checking username
				if(loginRest.isRegistered() && loginRest.isRegisteredWithOrg() && !loginRest.isUpdate()) {
					user = UserLocalServiceUtil.fetchUserByScreenName(company.getCompanyId(), loginRest.getUsername());
				} else if(loginRest.isRegistered()) {
					
				}
				
				//checking username & pwd
				long userId =  UserLocalServiceUtil.authenticateForBasic(company.getCompanyId(), CompanyConstants.AUTH_TYPE_SN, loginRest.getUsername(), generatedPassword);
				
				if(userId != 0) {
					verified = true;
					secret = user.getPassword();
				} else {
					error = true;
					throw new Exception(ExceptionConstant.INVALID_PWD);
				}
			} else {
				error = true;
				throw new Exception(ExceptionConstant.SESSION_EXPIRED);
			}
		} catch (Exception e) {
			error = true;
			errorMsg = e.getMessage();
		}
		
		response.put("verified", verified);
		response.put("error", error);
		response.put("errorMsg", errorMsg);
		response.put("secret", secret);
		response.put("username", loginRest.getUsername());
		
		return response.toString();
		
	}

	@POST
	@Path("/leykart/changepwd")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String leykartChangePwd(LoginRest changePwd) {
		
		System.out.println("---Inside changePwd API---");
		boolean error = false;
		String errorMsg = "";
		boolean success = false;
		String successMsg = "";
		User user = null;
	    String generatedPassword = null;
	    String generatedNewPassword = null;
		
		JSONObject response = JSONFactoryUtil.createJSONObject();
		
		try {
			CompanyCode code = CompanyCodeLocalServiceUtil.fetchByCode(changePwd.getCompanyCode(), true);
			Company company = CompanyLocalServiceUtil.fetchCompany(code.getCompanyId());
			
			//pwd decryption & encryption
			//AES decryption
			AES c = new AES("D4:6E:AC:3F:F0:BE"); 
			String decrStr = c.decrypt(changePwd.getPassword());
			String decrnewStr = c.decrypt(changePwd.getNewPassword());
			
			//MD5 encryption
			generatedPassword = MD5(decrStr);
			generatedNewPassword = MD5(decrnewStr);
			
			//checking username & pwd
			long userId =  UserLocalServiceUtil.authenticateForBasic(company.getCompanyId(), CompanyConstants.AUTH_TYPE_SN, changePwd.getUsername(), generatedPassword);
			
			if(userId == 0) {
				throw new Exception(ExceptionConstant.INVALID_CURRENT_PWD);
			}
			if(!changePwd.getPassword().equals(changePwd.getNewPassword())) {
				//changing pwd
				user = UserLocalServiceUtil.updatePassword(userId, generatedNewPassword, generatedNewPassword, false); 
				success = true;
				successMsg = "Password updated successfully";
			} else {
				error = true;
				throw new Exception(ExceptionConstant.NO_CHANGE_IN_PWDS);
			}
		} catch (Exception e) {
			error = true;
			errorMsg = e.getMessage();
		}
		
		response.put("success", success);
		response.put("successMsg", successMsg);
		response.put("error", error);
		response.put("errorMsg", errorMsg);
		response.put("username", changePwd.getUsername());
		
		return response.toString();
		
	}
	
	@POST
	@Path("/leykart/forgotpwd")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public String leykartForgotPwd(LoginRest forgotPwd) {
		
		System.out.println("---Inside leykartForgotPwd API---");
		boolean error = false;
		String errorMsg = "";
		boolean success = false;
		String successMsg = "";
		//String secret = "";
		boolean verified = false;
		User user = null;
		String generatedPassword = null;
		
		JSONObject response = JSONFactoryUtil.createJSONObject();
		
		try {
			CompanyCode code = CompanyCodeLocalServiceUtil.fetchByCode(forgotPwd.getCompanyCode(), true);
			Company company = CompanyLocalServiceUtil.fetchCompany(code.getCompanyId());
			Organization org = OrganizationLocalServiceUtil.fetchOrganization(code.getCompanyId(), forgotPwd.getOrgCode());
			Role role = RoleLocalServiceUtil.fetchRole(code.getCompanyId(), forgotPwd.getRoleCode());
			
			verified = OTPDetailsLocalServiceUtil.verifyOTP(forgotPwd.getUsername(), org, role, company, forgotPwd.getOtp());
			
			//pwd decryption & encryption
			//AES decryption
			AES c = new AES("D4:6E:AC:3F:F0:BE"); 
			String decrStr = c.decrypt(forgotPwd.getPassword());
			
			//MD5 encryption
			generatedPassword = MD5(decrStr);
			
			if(forgotPwd.isRegistered() && forgotPwd.isRegisteredWithOrg() && !forgotPwd.isUpdate()) {
				user = UserLocalServiceUtil.fetchUserByScreenName(company.getCompanyId(), forgotPwd.getUsername());
				user = UserLocalServiceUtil.updatePassword(user.getUserId(), generatedPassword, generatedPassword, false);
				success = true;
				successMsg = "Password updated successfully";
				//secret = user.getPassword();
			} else if(forgotPwd.isRegistered()) {
				
			}
		} catch(Exception e) {
			error = true;
			errorMsg = e.getMessage();
		}
		
		response.put("verified", verified);
		response.put("success", success);
		response.put("successMsg", successMsg);
		response.put("error", error);
		response.put("errorMsg", errorMsg);
		//response.put("secret", secret);
		response.put("username", forgotPwd.getUsername());
		
		return response.toString();
		
	}
	
	private String MD5(String decrStr) {
		
		String passwordToHash = null;
		String generatedPassword = null;
		
		try {
		// Create MessageDigest instance for MD5
		MessageDigest md = MessageDigest.getInstance("MD5");
		//Add password bytes to digest
		passwordToHash = decrStr;
		md.update(passwordToHash.getBytes());
		//Get the hash's bytes
		byte[] bytes = md.digest();
		//This bytes[] has bytes in decimal format;
		//Convert it to hexadecimal format
		StringBuilder sb = new StringBuilder();
		
		for(int i=0; i< bytes.length ;i++)
		{
			sb.append(Integer.toString((bytes[i] & 0xff) + 0x100, 16).substring(1));
		}
		
		//Get complete hashed password in hex format
		generatedPassword = sb.toString();
		} catch (NoSuchAlgorithmException e) {
			e.getMessage();
		}
		
		return generatedPassword;
		
	}

}