package cmu.upload.portlet;

import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.upload.UploadPortletRequest;
import com.liferay.portal.kernel.util.PortalUtil;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;

import org.osgi.service.component.annotations.Component;

import al.user.data.service.UserOrgDataLocalServiceUtil;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

/**
 * @author HTL_Vasudeva
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=Mag-Upload Portlet",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/upload.jsp",
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class UploadMagentoData extends MVCPortlet {
	
	public void updateMagentoId(ActionRequest actionRequest, ActionResponse actionResponse) {
		
		UploadPortletRequest uploadPortletRequest = PortalUtil.getUploadPortletRequest(actionRequest);
		
		InputStream inputStream = null;
	    String magentoId = null;
	    String userId = null;
	    Workbook workbook = null;
	    Sheet sheet = null;
	    int masterSheetRowIndex = 0;

        try {
            inputStream = new FileInputStream(uploadPortletRequest.getFile("sampleFile"));
            workbook = Workbook.getWorkbook(inputStream);
            sheet = workbook.getSheet(0); // Getting the first Sheet
			masterSheetRowIndex = sheet.getRows();
			
				for (int row = 1; row < masterSheetRowIndex; row++) {
					Cell cell1 = sheet.getCell(9, row);
					Cell cell2 = sheet.getCell(8, row);
					magentoId = cell1.getContents();
					userId = cell2.getContents();
					
					UserOrgDataLocalServiceUtil.updateMagentoId(userId, magentoId);
					SessionMessages.add(actionRequest, "success");
				}
			
        } catch (FileNotFoundException e) {
            System.out.println("Error on Reading File : "+e.getMessage());
        } catch (IOException e) {
			e.printStackTrace();
		} catch (BiffException e) {
			e.printStackTrace();
		} 
        
	}
	
}
