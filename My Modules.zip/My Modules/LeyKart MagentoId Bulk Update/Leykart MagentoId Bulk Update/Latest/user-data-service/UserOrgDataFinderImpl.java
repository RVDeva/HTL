package al.user.data.service.persistence.impl;

import com.liferay.portal.dao.orm.custom.sql.CustomSQLUtil;
import com.liferay.portal.kernel.dao.orm.QueryPos;
import com.liferay.portal.kernel.dao.orm.SQLQuery;
import com.liferay.portal.kernel.dao.orm.Session;

import java.util.List;

import al.user.data.model.UserOrgData;
import al.user.data.model.impl.UserOrgDataImpl;
import al.user.data.service.UserOrgDataLocalServiceUtil;
import al.user.data.service.persistence.UserOrgDataFinder;

/**
 * @author HTL_Vasudeva
 */
public class UserOrgDataFinderImpl extends UserOrgDataFinderBaseImpl implements UserOrgDataFinder {

	@SuppressWarnings("unchecked")
	public void doUpdateMagentoId(long userId, String magentoId) {
		
		System.out.println("---Inside doUpdateMagentoId method---");
		Session session = null;
		
		try {
			session = openSession(); // open ORM Session
			String sql = CustomSQLUtil.get(getClass(),"getDuplicateRecordQuery"); // get sql query return in default.xml
			 
			SQLQuery sqlQuery = session.createSQLQuery(sql);
			sqlQuery.setCacheable(false);
			sqlQuery.addEntity("UserOrgData",UserOrgDataImpl.class); // Add entity to be searched
			
			QueryPos queryPos = QueryPos.getInstance(sqlQuery); // Replace positional parameters in the query
			queryPos.add(userId);
			
			List<UserOrgData> list =  sqlQuery.list();
			
			UserOrgData userOrgData = list.get(0);
			userOrgData.setMagentoId(magentoId);
			UserOrgDataLocalServiceUtil.updateUserOrgData(userOrgData);
			
			System.out.println("userOrgData : "+userOrgData);
			
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			closeSession(session);
		}
		
	}
	
}
