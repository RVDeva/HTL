/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package al.user.data.service.impl;

import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.exception.ModelListenerException;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.model.Organization;
import com.liferay.portal.kernel.model.Phone;
import com.liferay.portal.kernel.model.Role;
import com.liferay.portal.kernel.model.User;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.service.UserLocalServiceUtil;
import com.liferay.portal.kernel.transaction.Propagation;
import com.liferay.portal.kernel.transaction.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Locale;

import aQute.bnd.annotation.ProviderType;
import al.common.constant.ExceptionConstant;
import al.user.address.service.UserAddressLocalServiceUtil;
import al.user.data.model.UserOrgData;
import al.user.data.model.UserSpecificData;
import al.user.data.service.SaveUserService;
import al.user.data.service.UserOrgBankDataLocalServiceUtil;
import al.user.data.service.UserOrgDataLocalServiceUtil;
import al.user.data.service.UserSpecificDataLocalServiceUtil;
import al.user.data.service.base.UserOrgDataLocalServiceBaseImpl;

/**
 * The implementation of the user org data local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link al.user.data.service.UserOrgDataLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see UserOrgDataLocalServiceBaseImpl
 * @see al.user.data.service.UserOrgDataLocalServiceUtil
 */
@ProviderType
public class UserOrgDataLocalServiceImpl extends UserOrgDataLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this class directly. Always use {@link al.user.data.service.UserOrgDataLocalServiceUtil} to access the user org data local service.
	 */
	
	public UserOrgData fetchByUserIdOrgIdRoleId(long userId, long orgId, long roleId){
		return userOrgDataPersistence.fetchByUserIdAndOrgIdAndRoleId(userId, orgId, roleId);
	}
	
	public List<UserOrgData> fetchByUserIdAndOrgId(long userId, long orgId){
		return userOrgDataPersistence.findByUserIdAndOrgId(userId, orgId);
	}
	
	public UserOrgData saveAndUpdate(
			long userId, long companyId, long createdBy, long modifiedBy,
			long orgId, Role role, String garageName, String garagePincode, 
			long fleetManagerUserId, String gstIn, String businessPanCard,
			long userOrgDataId, boolean active, boolean status, long shift, String magentoId
			){
		UserOrgData userOrgData = null;
		if(userOrgDataId>0){
			userOrgData = UserOrgDataLocalServiceUtil.fetchUserOrgData(userOrgDataId);
		}else{
			userOrgData = UserOrgDataLocalServiceUtil.createUserOrgData(CounterLocalServiceUtil.increment(
					UserOrgData.class.getName()));
			userOrgData.setCreateDate(new Date());
			userOrgData.setCreatedBy(createdBy);
		}
		userOrgData.setActive(active);
		userOrgData.setUserId(userId);
		userOrgData.setStatus(status);
		userOrgData.setModifiedBy(modifiedBy);
		userOrgData.setModifiedDate(new Date());
		userOrgData.setCompanyId(companyId);
		userOrgData.setOrgId(orgId);
		userOrgData.setRoleId(role.getRoleId());
		userOrgData.setGarageName(garageName);
		userOrgData.setGaragePincode(garagePincode);
		if(fleetManagerUserId>0)
		userOrgData.setFleetManagerUserId(fleetManagerUserId);
		userOrgData.setGstIn(gstIn);
		if(shift>0)
		userOrgData.setShift(shift);
		if(magentoId!=null && !magentoId.isEmpty())
		userOrgData.setMagentoId(magentoId);
		userOrgData.setBusinessPanCard(businessPanCard);
		return userOrgDataPersistence.update(userOrgData);
	}
	
	public UserOrgData fetchByMagentoIdAndOrgIdAndRoleId(String magentoId, long orgId, long roleId){
		return null;
	}
	
	/**
	 * This method is used to create and update the user
	 */
	@Transactional(readOnly = false, rollbackFor = { PortalException.class,SystemException.class,ModelListenerException.class }, propagation = Propagation.REQUIRED)
	public UserOrgData saveUser(
			long creatorUserId, long companyId, boolean autoPassword,
			String password1, String password2, boolean autoScreenName, String screenName,
			String emailAddress, long facebookId, String openId, Locale locale, String firstName,
			String middleName, String lastName, long prefixId, long suffixId, boolean male,
			int birthdayMonth, int birthdayDay, int birthdayYear, String jobTitle, long[] groupIds,
			long[] organizationIds, long[] roleIds, long[] userGroupIds, boolean sendEmail, ServiceContext
			serviceContext, String primaryMobile, String secondaryMobile, 
			String addressLineOne, String addressLineTwo, String companyName,
			String addressUserFirstName, String addressUserLastName, 
			String addressPrimaryPhone, String addressSecondaryPhone,
			boolean bilingAddress, boolean shipingAddress,
			String landMark, String pincode, String city, long stateId, long countryId, long userId,
			Organization org, Role role, String garageName, String garagePincode, 
			long fleetManagerUserId, String gstIn, String businessPanCard,
			long userOrgDataId, boolean userOrgDataActive, boolean userOrgDataStatus, long shift,
			String bankAccNumber, String bankAccName,
			String bankName, String bankBranch, String bankIFSCCode, String ccAvenueId,
			String pancard, String aadharcard, String sapId,String dbmId, String magentoId
			) throws PortalException{
		
		UserOrgData userOrgData =null;
		try{
			User user = SaveUserService.saveUser(creatorUserId, companyId, autoPassword, password1, password2, 
					autoScreenName, screenName, emailAddress, facebookId, openId,
					locale, firstName, middleName, lastName, prefixId, suffixId, male,
					birthdayMonth, birthdayDay, birthdayYear, jobTitle, groupIds, organizationIds,
					roleIds, userGroupIds, sendEmail, serviceContext, primaryMobile, secondaryMobile,
					addressLineOne,  addressLineTwo, companyName,
					addressUserFirstName, addressUserLastName, addressPrimaryPhone, addressSecondaryPhone,
					bilingAddress, shipingAddress,
					landMark, 
					pincode, city, stateId, countryId, userId, role, org);
			
			userOrgData = UserOrgDataLocalServiceUtil.saveAndUpdate(user.getUserId(), companyId, user.getUserId(), user.getUserId(),
					org.getOrganizationId(), role, garageName, garagePincode, fleetManagerUserId, gstIn, businessPanCard,
					userOrgDataId, userOrgDataActive, userOrgDataStatus, shift, magentoId);
			
			UserSpecificDataLocalServiceUtil.saveAndUpdate(user.getUserId(), companyId, user.getUserId(),
					user.getUserId(), pancard, aadharcard, sapId, dbmId);
			
			UserOrgBankDataLocalServiceUtil.saveAndUpdate(user.getUserId(), companyId, user.getUserId(), 
					user.getUserId(), org.getOrganizationId(), role.getRoleId(), bankAccNumber,
					bankAccName, bankName, bankBranch, bankIFSCCode, ccAvenueId);
		}catch(Exception e){
			throw new PortalException(e.getMessage());
		}
		
	return userOrgData;	
	}
	
	public void activateDeactivateUser(
			long userId, long companyId, long orgId, Role role, 
			long userOrgDataId, boolean active, boolean status
			) throws Exception{
		User user = UserLocalServiceUtil.fetchUser(userId);
		if(user!=null){
			UserOrgData userOrgData = UserOrgDataLocalServiceUtil.findById(userOrgDataId);
			if(userOrgData!=null && userOrgData.getUserId()==user.getUserId()){
				userOrgData.setActive(active);
				userOrgData.setStatus(status);
				userOrgDataPersistence.update(userOrgData);
			}else{
				throw new Exception(ExceptionConstant.NO_SUCH_USER);
			}
			
			List<UserOrgData> list = userOrgDataPersistence.findByUserId(userId);
			int count = 0;
			if(list!=null && list.size()>0){
				for(UserOrgData data : list){
					if(!data.isActive()&&!data.isStatus()){
						count = count++;
					}
				}
				if(count == list.size() && !active){
						user.setStatus(5);
				}else{
					user.setStatus(0);
				}
				UserLocalServiceUtil.updateUser(user);
			}
			
		}else{
			throw new Exception(ExceptionConstant.NO_SUCH_USER);
		}
	}
	
	public void updateGoToHome(long userOrgId, boolean goToHome) throws PortalException{
		UserOrgData userOrgData = UserOrgDataLocalServiceUtil.fetchUserOrgData(userOrgId);
		if(userOrgData!=null){
			userOrgData.setFleetGoToHome(goToHome);
			UserOrgDataLocalServiceUtil.updateUserOrgData(userOrgData);
		}else{
			throw new PortalException(ExceptionConstant.NO_SUCH_USER);
		}
	}
	
	public void updateGstIn(long userOrgId, String gstIn) throws PortalException{
		UserOrgData userOrgData = UserOrgDataLocalServiceUtil.fetchUserOrgData(userOrgId);
		if(userOrgData!=null){
			userOrgData.setGstIn(gstIn);
			UserOrgDataLocalServiceUtil.updateUserOrgData(userOrgData);
		}else{
			throw new PortalException(ExceptionConstant.NO_SUCH_USER);
		}
	}
	
	public UserOrgData findById(long id) throws Exception{
		UserOrgData userOrgData = userOrgDataLocalService.fetchUserOrgData(id);
		if(userOrgData==null){
			throw new Exception(ExceptionConstant.NO_SUCH_USER);
		}
		return userOrgData;
	}
	
	public JSONObject getUserData(long userOrgDataId) throws Exception{
		JSONObject userData = JSONFactoryUtil.createJSONObject();
		
		UserOrgData userOrgData = UserOrgDataLocalServiceUtil.findById(userOrgDataId);
		User user = UserLocalServiceUtil.fetchUser(userOrgData.getUserId());
		UserSpecificData userSpecificData = UserSpecificDataLocalServiceUtil.fetchByUserId(user.getUserId());
		userData.put("address", UserAddressLocalServiceUtil.getAddressJsonData(user.getUserId()));
		userData.put("bankDetails", UserOrgBankDataLocalServiceUtil.getBankDetailsJsonObejct(userOrgData.getUserId(),
				userOrgData.getOrgId(), userOrgData.getRoleId()));
		userData.put("firstName", user.getFirstName());
		userData.put("lastName", user.getLastName());
		userData.put("emailId", user.getEmailAddress());
		userData.put("primaryMobile", user.getScreenName());
		userData.put("secondaryMobile", "");
		if(user.getPhones()!=null && user.getPhones().size()>1){
			for(Phone phone :user.getPhones()){
				if(!phone.isPrimary()){
					userData.put("secondaryMobile", phone.getNumber());
				}
			}
		}
		userData.put("userId", user.getUserId() );
		userData.put("userOrgId", userOrgDataId );
		userData.put("magentoId", userOrgData.getMagentoId());
		userData.put("gstIn", userOrgData.getGstIn());
		userData.put("businessPancard", userOrgData.getBusinessPanCard());
		userData.put("userPancard", userSpecificData.getPancard());
		userData.put("userAadharcard", userSpecificData.getAadharcard());
		userData.put("sapId", userSpecificData.getSapId());
		userData.put("dmsId", userSpecificData.getDbmId());
		
		return userData;
	}
	
	public void updateMagentoId(String userIds, String magentoId) {
		
		System.out.println("---Inside updateMagentoId method---");
		long userId = Long.parseLong(userIds);
		userOrgDataFinder.doUpdateMagentoId(userId, magentoId);
		
	}
	
}