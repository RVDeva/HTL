package com.al.dealer.locator.web.portlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.portlet.Portlet;
import javax.portlet.PortletException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.osgi.service.component.annotations.Component;

import com.al.dealer.locator.web.constants.DealerLocatorWebPortletKeys;
import com.liferay.city.model.City;
import com.liferay.city.service.CityLocalServiceUtil;
import com.liferay.dealer.location.model.DealerLocation;
import com.liferay.dealer.location.service.DealerLocationLocalServiceUtil;
import com.liferay.dealer.location.service.DealerLocation_CategoryLocalServiceUtil;
import com.liferay.dealer.servicetype.service.Dealerlocation_ServiceTypeLocalServiceUtil;
import com.liferay.district.model.District;
import com.liferay.district.service.DistrictLocalServiceUtil;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.json.JSONArray;
import com.liferay.portal.kernel.json.JSONFactoryUtil;
import com.liferay.portal.kernel.json.JSONObject;
import com.liferay.portal.kernel.model.Country;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.service.CountryServiceUtil;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.Validator;
import com.liferay.portal.kernel.util.WebKeys;
import com.liferay.state.model.State;
import com.liferay.state.service.StateLocalServiceUtil;

/**
 * @author Mohit
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=DealerLocator-web Portlet",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=ALCorp-" + DealerLocatorWebPortletKeys.DealerLocatorWeb,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class DealerLocatorWebPortlet extends MVCPortlet {
	@Override
	public void serveResource(ResourceRequest resourceRequest, ResourceResponse resourceResponse)
			throws IOException, PortletException {
		
		long countryId = ParamUtil.getLong(resourceRequest, "countryId");
		JSONArray jsonArray = JSONFactoryUtil.createJSONArray();
		String change = ParamUtil.getString(resourceRequest, "change");
		ThemeDisplay themeDisplay = (ThemeDisplay) resourceRequest.getAttribute(WebKeys.THEME_DISPLAY);
		
		if(!Validator.isBlank(change)) {
			if(change.equals("country")) {
				 List<State> states = StateLocalServiceUtil.getByCountryId(countryId);
				 String countryCode ="";
			     try {
					Country country = CountryServiceUtil.getCountry(countryId);
					countryCode = country.getA2();
				} catch (PortalException e) {
					
				}
			       jsonArray.put(countryCode);
			         states.stream().forEach(state -> {
			     	  JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
			     	  jsonObject.put("Id", state.getStateId());
			     	  jsonObject.put("name", state.getName(Locale.US));
			     	  jsonArray.put(jsonObject);
			     	  jsonObject = null;
			        });
			} else if(change.equals("sate")) {
			    long stateId = ParamUtil.getLong(resourceRequest, "stateId");
		   	    List<City> citiesBasedOnCountry =  CityLocalServiceUtil.getByCountryId(countryId);
		     	citiesBasedOnCountry.stream().filter( city-> city.getStateId() == stateId).forEach(city -> {
		         	  JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
		         	  jsonObject.put("Id", city.getCityId());
		         	  jsonObject.put("name", city.getName(Locale.US));
		         	  jsonArray.put(jsonObject);
		         	  jsonObject = null;
		            });
			}else if(change.equals("city")) {
			    long stateId = ParamUtil.getLong(resourceRequest, "stateId");
		   	    List<District> districts =  DistrictLocalServiceUtil.getDistrictsByStateId(stateId);
		   	   	districts.stream().forEach(district -> {
		       	  JSONObject jsonObject = JSONFactoryUtil.createJSONObject();
		       	  jsonObject.put("Id", district.getDistrictId());
		       	  jsonObject.put("name", district.getName(Locale.US));
		       	  jsonArray.put(jsonObject);
		       	  jsonObject = null;
		          });
			} 
			 try {
					PrintWriter out = resourceResponse.getWriter();
					out.print(jsonArray);
				} catch (IOException e) {
					e.printStackTrace();
				}
			 
		} else {
			getDealerLocationsData(resourceRequest, resourceResponse);
		}
       
  }
	
	@Override
	public void render(RenderRequest renderRequest, RenderResponse renderResponse)
			throws IOException, PortletException {
	
		// TODO Auto-generated method stub
		super.render(renderRequest, renderResponse);
	}
	
	private void getDealerLocationsData(ResourceRequest resourceRequest, ResourceResponse resourceResponse) {
		String inputData = ParamUtil.getString(resourceRequest, "inputData");
		try {
			JSONObject jsonObject = JSONFactoryUtil.createJSONObject(inputData);
			/*System.out.println("networkType::"+jsonObject.get("networkType"));
			System.out.println("countryId::"+jsonObject.get("countryId"));
			System.out.println("stateId::"+jsonObject.get("stateId"));
			System.out.println("districtId::"+jsonObject.get("districtId"));
			System.out.println("cityId::"+jsonObject.get("cityId"));
			System.out.println("productId::"+jsonObject.get("productId"));
			System.out.println("productTypeId::"+jsonObject.get("productTypeId"));
			*/Set<Long> dealerLocationIds  = null;
			
			long networkTypeId = jsonObject.getLong("networkType");
			long countryId = jsonObject.getLong("countryId"); 
			long stateId = jsonObject.getLong("stateId"); 
			long districtId = jsonObject.getLong("districtId"); 
			String cityName = jsonObject.getString("cityName"); 
			long productCategoryId = jsonObject.getLong("productId"); 
			long productTypeId = jsonObject.getLong("productTypeId"); 
			
			boolean isOffice = false;
			if(networkTypeId == 0) {
				isOffice =  true;
			}
			
			 dealerLocationIds = DealerLocationLocalServiceUtil.getDealerLocationIdsByC_S_D_C_Ids(countryId, stateId, districtId, cityName, isOffice);
			
			 System.out.println("dealerLocationIds:::"+dealerLocationIds.size());
			 if(!isOffice) {
				Set<Long> dealerLocatioIds_ServiceTypeId = Dealerlocation_ServiceTypeLocalServiceUtil.getDealerLocationIdsByServiceTypeId(networkTypeId);
				dealerLocationIds.retainAll(dealerLocatioIds_ServiceTypeId);
				Set<Long> dealerLocatioIds_productTypeId = DealerLocation_CategoryLocalServiceUtil.getDealerLocationIdsByProductCategoryId_TypeId(productCategoryId,
		    			productTypeId);
				dealerLocationIds.retainAll(dealerLocatioIds_productTypeId);
			}
		
	    	JSONArray locations = JSONFactoryUtil.createJSONArray();
			JSONArray location = null;
		    JSONObject address = null;
		   
		    for(long dealerId : dealerLocationIds) {
		    	
		    	DealerLocation dealerLocation =DealerLocationLocalServiceUtil.fetchDealerLocation(dealerId);
		    	address = JSONFactoryUtil.createJSONObject();
		  		address.put("name", dealerLocation.getDealerName());
		  		address.put("address", dealerLocation.getAddress());
		  		address.put("email",dealerLocation.getEmail());
		  		address.put("contact", dealerLocation.getPhNumber());
		  		location =JSONFactoryUtil.createJSONArray();
		  		location.put(address);
		  		location.put(dealerLocation.getLatitude());
		  		location.put(dealerLocation.getLongitude());
		  		location.put(dealerLocation.getMarkerColor());
		  		locations.put(location);
		    }
		    
		  
		    PrintWriter out = resourceResponse.getWriter();
			out.print(locations);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}