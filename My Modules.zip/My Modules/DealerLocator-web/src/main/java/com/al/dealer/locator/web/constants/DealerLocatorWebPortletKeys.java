package com.al.dealer.locator.web.constants;

/**
 * @author Mohit
 */
public class DealerLocatorWebPortletKeys {

	public static final String DealerLocatorWeb = "DealerLocatorWeb";

}