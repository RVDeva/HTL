public static String WriteObjectToFile(Object respObj, HttpServletRequest request) {
		 
	try {
		
		String phyPath = request.getSession().getServletContext().getRealPath("/");
		
		//File file = ResourceUtils.getFile("classpath:config/sample.txt");
				 
		FileOutputStream fileOut = new FileOutputStream(phyPath+filepath);
		ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
		
		objectOut.writeObject(respObj);
		objectOut.write(("").getBytes());
		objectOut.close();
		
		File file = new File(phyPath+filepath);
		String fileSize = file.length() / 1024 + " kb";
		//System.out.println(fileSize);
	} catch (Exception e) {
		e.printStackTrace();
	}
	return fileSize;
	
}



private static String getFileSizeKiloBytes(File file) {
	return (double) file.length() / 1024 + "  kb";
}
	
private static String getFileSizeMegaBytes(File file) {
	return (double) file.length() / (1024 * 1024) + " mb";
}

private static String getFileSizeBytes(File file) {
	return file.length() + " bytes";
}
