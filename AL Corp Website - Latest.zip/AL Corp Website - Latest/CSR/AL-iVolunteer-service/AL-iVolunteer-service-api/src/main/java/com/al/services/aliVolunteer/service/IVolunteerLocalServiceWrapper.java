/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.al.services.aliVolunteer.service;

import aQute.bnd.annotation.ProviderType;

import com.liferay.portal.kernel.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link IVolunteerLocalService}.
 *
 * @author Brian Wing Shun Chan
 * @see IVolunteerLocalService
 * @generated
 */
@ProviderType
public class IVolunteerLocalServiceWrapper implements IVolunteerLocalService,
	ServiceWrapper<IVolunteerLocalService> {
	public IVolunteerLocalServiceWrapper(
		IVolunteerLocalService iVolunteerLocalService) {
		_iVolunteerLocalService = iVolunteerLocalService;
	}

	/**
	* Adds the i volunteer to the database. Also notifies the appropriate model listeners.
	*
	* @param iVolunteer the i volunteer
	* @return the i volunteer that was added
	*/
	@Override
	public com.al.services.aliVolunteer.model.IVolunteer addIVolunteer(
		com.al.services.aliVolunteer.model.IVolunteer iVolunteer) {
		return _iVolunteerLocalService.addIVolunteer(iVolunteer);
	}

	/**
	* This method is used to create iVolunteer
	*/
	@Override
	public com.al.services.aliVolunteer.model.IVolunteer create(
		long volunteerId, long groupId, long companyId, long userId,
		String name, String email, String phoneNumber, String subject,
		String address, String message) {
		return _iVolunteerLocalService.create(volunteerId, groupId, companyId,
			userId, name, email, phoneNumber, subject, address, message);
	}

	/**
	* Creates a new i volunteer with the primary key. Does not add the i volunteer to the database.
	*
	* @param volunteerId the primary key for the new i volunteer
	* @return the new i volunteer
	*/
	@Override
	public com.al.services.aliVolunteer.model.IVolunteer createIVolunteer(
		long volunteerId) {
		return _iVolunteerLocalService.createIVolunteer(volunteerId);
	}

	/**
	* Deletes the i volunteer from the database. Also notifies the appropriate model listeners.
	*
	* @param iVolunteer the i volunteer
	* @return the i volunteer that was removed
	*/
	@Override
	public com.al.services.aliVolunteer.model.IVolunteer deleteIVolunteer(
		com.al.services.aliVolunteer.model.IVolunteer iVolunteer) {
		return _iVolunteerLocalService.deleteIVolunteer(iVolunteer);
	}

	/**
	* Deletes the i volunteer with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param volunteerId the primary key of the i volunteer
	* @return the i volunteer that was removed
	* @throws PortalException if a i volunteer with the primary key could not be found
	*/
	@Override
	public com.al.services.aliVolunteer.model.IVolunteer deleteIVolunteer(
		long volunteerId)
		throws com.liferay.portal.kernel.exception.PortalException {
		return _iVolunteerLocalService.deleteIVolunteer(volunteerId);
	}

	/**
	* @throws PortalException
	*/
	@Override
	public com.liferay.portal.kernel.model.PersistedModel deletePersistedModel(
		com.liferay.portal.kernel.model.PersistedModel persistedModel)
		throws com.liferay.portal.kernel.exception.PortalException {
		return _iVolunteerLocalService.deletePersistedModel(persistedModel);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery() {
		return _iVolunteerLocalService.dynamicQuery();
	}

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	*/
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {
		return _iVolunteerLocalService.dynamicQuery(dynamicQuery);
	}

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.al.services.aliVolunteer.model.impl.IVolunteerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	*/
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end) {
		return _iVolunteerLocalService.dynamicQuery(dynamicQuery, start, end);
	}

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.al.services.aliVolunteer.model.impl.IVolunteerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	*/
	@Override
	public <T> java.util.List<T> dynamicQuery(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery, int start,
		int end,
		com.liferay.portal.kernel.util.OrderByComparator<T> orderByComparator) {
		return _iVolunteerLocalService.dynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	* Returns the number of rows matching the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows matching the dynamic query
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery) {
		return _iVolunteerLocalService.dynamicQueryCount(dynamicQuery);
	}

	/**
	* Returns the number of rows matching the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows matching the dynamic query
	*/
	@Override
	public long dynamicQueryCount(
		com.liferay.portal.kernel.dao.orm.DynamicQuery dynamicQuery,
		com.liferay.portal.kernel.dao.orm.Projection projection) {
		return _iVolunteerLocalService.dynamicQueryCount(dynamicQuery,
			projection);
	}

	@Override
	public com.al.services.aliVolunteer.model.IVolunteer fetchIVolunteer(
		long volunteerId) {
		return _iVolunteerLocalService.fetchIVolunteer(volunteerId);
	}

	/**
	* Returns the i volunteer matching the UUID and group.
	*
	* @param uuid the i volunteer's UUID
	* @param groupId the primary key of the group
	* @return the matching i volunteer, or <code>null</code> if a matching i volunteer could not be found
	*/
	@Override
	public com.al.services.aliVolunteer.model.IVolunteer fetchIVolunteerByUuidAndGroupId(
		String uuid, long groupId) {
		return _iVolunteerLocalService.fetchIVolunteerByUuidAndGroupId(uuid,
			groupId);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery getActionableDynamicQuery() {
		return _iVolunteerLocalService.getActionableDynamicQuery();
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.ExportActionableDynamicQuery getExportActionableDynamicQuery(
		com.liferay.exportimport.kernel.lar.PortletDataContext portletDataContext) {
		return _iVolunteerLocalService.getExportActionableDynamicQuery(portletDataContext);
	}

	@Override
	public com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery getIndexableActionableDynamicQuery() {
		return _iVolunteerLocalService.getIndexableActionableDynamicQuery();
	}

	/**
	* Returns the i volunteer with the primary key.
	*
	* @param volunteerId the primary key of the i volunteer
	* @return the i volunteer
	* @throws PortalException if a i volunteer with the primary key could not be found
	*/
	@Override
	public com.al.services.aliVolunteer.model.IVolunteer getIVolunteer(
		long volunteerId)
		throws com.liferay.portal.kernel.exception.PortalException {
		return _iVolunteerLocalService.getIVolunteer(volunteerId);
	}

	/**
	* Returns the i volunteer matching the UUID and group.
	*
	* @param uuid the i volunteer's UUID
	* @param groupId the primary key of the group
	* @return the matching i volunteer
	* @throws PortalException if a matching i volunteer could not be found
	*/
	@Override
	public com.al.services.aliVolunteer.model.IVolunteer getIVolunteerByUuidAndGroupId(
		String uuid, long groupId)
		throws com.liferay.portal.kernel.exception.PortalException {
		return _iVolunteerLocalService.getIVolunteerByUuidAndGroupId(uuid,
			groupId);
	}

	/**
	* Returns a range of all the i volunteers.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.al.services.aliVolunteer.model.impl.IVolunteerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of i volunteers
	* @param end the upper bound of the range of i volunteers (not inclusive)
	* @return the range of i volunteers
	*/
	@Override
	public java.util.List<com.al.services.aliVolunteer.model.IVolunteer> getIVolunteers(
		int start, int end) {
		return _iVolunteerLocalService.getIVolunteers(start, end);
	}

	/**
	* Returns all the i volunteers matching the UUID and company.
	*
	* @param uuid the UUID of the i volunteers
	* @param companyId the primary key of the company
	* @return the matching i volunteers, or an empty list if no matches were found
	*/
	@Override
	public java.util.List<com.al.services.aliVolunteer.model.IVolunteer> getIVolunteersByUuidAndCompanyId(
		String uuid, long companyId) {
		return _iVolunteerLocalService.getIVolunteersByUuidAndCompanyId(uuid,
			companyId);
	}

	/**
	* Returns a range of i volunteers matching the UUID and company.
	*
	* @param uuid the UUID of the i volunteers
	* @param companyId the primary key of the company
	* @param start the lower bound of the range of i volunteers
	* @param end the upper bound of the range of i volunteers (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the range of matching i volunteers, or an empty list if no matches were found
	*/
	@Override
	public java.util.List<com.al.services.aliVolunteer.model.IVolunteer> getIVolunteersByUuidAndCompanyId(
		String uuid, long companyId, int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<com.al.services.aliVolunteer.model.IVolunteer> orderByComparator) {
		return _iVolunteerLocalService.getIVolunteersByUuidAndCompanyId(uuid,
			companyId, start, end, orderByComparator);
	}

	/**
	* Returns the number of i volunteers.
	*
	* @return the number of i volunteers
	*/
	@Override
	public int getIVolunteersCount() {
		return _iVolunteerLocalService.getIVolunteersCount();
	}

	/**
	* Returns the OSGi service identifier.
	*
	* @return the OSGi service identifier
	*/
	@Override
	public String getOSGiServiceIdentifier() {
		return _iVolunteerLocalService.getOSGiServiceIdentifier();
	}

	@Override
	public com.liferay.portal.kernel.model.PersistedModel getPersistedModel(
		java.io.Serializable primaryKeyObj)
		throws com.liferay.portal.kernel.exception.PortalException {
		return _iVolunteerLocalService.getPersistedModel(primaryKeyObj);
	}

	/**
	* Updates the i volunteer in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param iVolunteer the i volunteer
	* @return the i volunteer that was updated
	*/
	@Override
	public com.al.services.aliVolunteer.model.IVolunteer updateIVolunteer(
		com.al.services.aliVolunteer.model.IVolunteer iVolunteer) {
		return _iVolunteerLocalService.updateIVolunteer(iVolunteer);
	}

	@Override
	public IVolunteerLocalService getWrappedService() {
		return _iVolunteerLocalService;
	}

	@Override
	public void setWrappedService(IVolunteerLocalService iVolunteerLocalService) {
		_iVolunteerLocalService = iVolunteerLocalService;
	}

	private IVolunteerLocalService _iVolunteerLocalService;
}