/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.al.services.aliVolunteer.model;

import aQute.bnd.annotation.ProviderType;

import com.liferay.expando.kernel.model.ExpandoBridge;

import com.liferay.exportimport.kernel.lar.StagedModelType;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.service.ServiceContext;

import java.io.Serializable;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * <p>
 * This class is a wrapper for {@link IVolunteer}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see IVolunteer
 * @generated
 */
@ProviderType
public class IVolunteerWrapper implements IVolunteer, ModelWrapper<IVolunteer> {
	public IVolunteerWrapper(IVolunteer iVolunteer) {
		_iVolunteer = iVolunteer;
	}

	@Override
	public Class<?> getModelClass() {
		return IVolunteer.class;
	}

	@Override
	public String getModelClassName() {
		return IVolunteer.class.getName();
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("uuid", getUuid());
		attributes.put("volunteerId", getVolunteerId());
		attributes.put("groupId", getGroupId());
		attributes.put("companyId", getCompanyId());
		attributes.put("userId", getUserId());
		attributes.put("createDate", getCreateDate());
		attributes.put("modifiedDate", getModifiedDate());
		attributes.put("name", getName());
		attributes.put("email", getEmail());
		attributes.put("phoneNumber", getPhoneNumber());
		attributes.put("subject", getSubject());
		attributes.put("address", getAddress());
		attributes.put("message", getMessage());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		String uuid = (String)attributes.get("uuid");

		if (uuid != null) {
			setUuid(uuid);
		}

		Long volunteerId = (Long)attributes.get("volunteerId");

		if (volunteerId != null) {
			setVolunteerId(volunteerId);
		}

		Long groupId = (Long)attributes.get("groupId");

		if (groupId != null) {
			setGroupId(groupId);
		}

		Long companyId = (Long)attributes.get("companyId");

		if (companyId != null) {
			setCompanyId(companyId);
		}

		Long userId = (Long)attributes.get("userId");

		if (userId != null) {
			setUserId(userId);
		}

		Date createDate = (Date)attributes.get("createDate");

		if (createDate != null) {
			setCreateDate(createDate);
		}

		Date modifiedDate = (Date)attributes.get("modifiedDate");

		if (modifiedDate != null) {
			setModifiedDate(modifiedDate);
		}

		String name = (String)attributes.get("name");

		if (name != null) {
			setName(name);
		}

		String email = (String)attributes.get("email");

		if (email != null) {
			setEmail(email);
		}

		String phoneNumber = (String)attributes.get("phoneNumber");

		if (phoneNumber != null) {
			setPhoneNumber(phoneNumber);
		}

		String subject = (String)attributes.get("subject");

		if (subject != null) {
			setSubject(subject);
		}

		String address = (String)attributes.get("address");

		if (address != null) {
			setAddress(address);
		}

		String message = (String)attributes.get("message");

		if (message != null) {
			setMessage(message);
		}
	}

	@Override
	public Object clone() {
		return new IVolunteerWrapper((IVolunteer)_iVolunteer.clone());
	}

	@Override
	public int compareTo(IVolunteer iVolunteer) {
		return _iVolunteer.compareTo(iVolunteer);
	}

	/**
	* Returns the address of this i volunteer.
	*
	* @return the address of this i volunteer
	*/
	@Override
	public String getAddress() {
		return _iVolunteer.getAddress();
	}

	/**
	* Returns the company ID of this i volunteer.
	*
	* @return the company ID of this i volunteer
	*/
	@Override
	public long getCompanyId() {
		return _iVolunteer.getCompanyId();
	}

	/**
	* Returns the create date of this i volunteer.
	*
	* @return the create date of this i volunteer
	*/
	@Override
	public Date getCreateDate() {
		return _iVolunteer.getCreateDate();
	}

	/**
	* Returns the email of this i volunteer.
	*
	* @return the email of this i volunteer
	*/
	@Override
	public String getEmail() {
		return _iVolunteer.getEmail();
	}

	@Override
	public ExpandoBridge getExpandoBridge() {
		return _iVolunteer.getExpandoBridge();
	}

	/**
	* Returns the group ID of this i volunteer.
	*
	* @return the group ID of this i volunteer
	*/
	@Override
	public long getGroupId() {
		return _iVolunteer.getGroupId();
	}

	/**
	* Returns the message of this i volunteer.
	*
	* @return the message of this i volunteer
	*/
	@Override
	public String getMessage() {
		return _iVolunteer.getMessage();
	}

	/**
	* Returns the modified date of this i volunteer.
	*
	* @return the modified date of this i volunteer
	*/
	@Override
	public Date getModifiedDate() {
		return _iVolunteer.getModifiedDate();
	}

	/**
	* Returns the name of this i volunteer.
	*
	* @return the name of this i volunteer
	*/
	@Override
	public String getName() {
		return _iVolunteer.getName();
	}

	/**
	* Returns the phone number of this i volunteer.
	*
	* @return the phone number of this i volunteer
	*/
	@Override
	public String getPhoneNumber() {
		return _iVolunteer.getPhoneNumber();
	}

	/**
	* Returns the primary key of this i volunteer.
	*
	* @return the primary key of this i volunteer
	*/
	@Override
	public long getPrimaryKey() {
		return _iVolunteer.getPrimaryKey();
	}

	@Override
	public Serializable getPrimaryKeyObj() {
		return _iVolunteer.getPrimaryKeyObj();
	}

	/**
	* Returns the subject of this i volunteer.
	*
	* @return the subject of this i volunteer
	*/
	@Override
	public String getSubject() {
		return _iVolunteer.getSubject();
	}

	/**
	* Returns the user ID of this i volunteer.
	*
	* @return the user ID of this i volunteer
	*/
	@Override
	public long getUserId() {
		return _iVolunteer.getUserId();
	}

	/**
	* Returns the user uuid of this i volunteer.
	*
	* @return the user uuid of this i volunteer
	*/
	@Override
	public String getUserUuid() {
		return _iVolunteer.getUserUuid();
	}

	/**
	* Returns the uuid of this i volunteer.
	*
	* @return the uuid of this i volunteer
	*/
	@Override
	public String getUuid() {
		return _iVolunteer.getUuid();
	}

	/**
	* Returns the volunteer ID of this i volunteer.
	*
	* @return the volunteer ID of this i volunteer
	*/
	@Override
	public long getVolunteerId() {
		return _iVolunteer.getVolunteerId();
	}

	@Override
	public int hashCode() {
		return _iVolunteer.hashCode();
	}

	@Override
	public boolean isCachedModel() {
		return _iVolunteer.isCachedModel();
	}

	@Override
	public boolean isEscapedModel() {
		return _iVolunteer.isEscapedModel();
	}

	@Override
	public boolean isNew() {
		return _iVolunteer.isNew();
	}

	@Override
	public void persist() {
		_iVolunteer.persist();
	}

	/**
	* Sets the address of this i volunteer.
	*
	* @param address the address of this i volunteer
	*/
	@Override
	public void setAddress(String address) {
		_iVolunteer.setAddress(address);
	}

	@Override
	public void setCachedModel(boolean cachedModel) {
		_iVolunteer.setCachedModel(cachedModel);
	}

	/**
	* Sets the company ID of this i volunteer.
	*
	* @param companyId the company ID of this i volunteer
	*/
	@Override
	public void setCompanyId(long companyId) {
		_iVolunteer.setCompanyId(companyId);
	}

	/**
	* Sets the create date of this i volunteer.
	*
	* @param createDate the create date of this i volunteer
	*/
	@Override
	public void setCreateDate(Date createDate) {
		_iVolunteer.setCreateDate(createDate);
	}

	/**
	* Sets the email of this i volunteer.
	*
	* @param email the email of this i volunteer
	*/
	@Override
	public void setEmail(String email) {
		_iVolunteer.setEmail(email);
	}

	@Override
	public void setExpandoBridgeAttributes(
		com.liferay.portal.kernel.model.BaseModel<?> baseModel) {
		_iVolunteer.setExpandoBridgeAttributes(baseModel);
	}

	@Override
	public void setExpandoBridgeAttributes(ExpandoBridge expandoBridge) {
		_iVolunteer.setExpandoBridgeAttributes(expandoBridge);
	}

	@Override
	public void setExpandoBridgeAttributes(ServiceContext serviceContext) {
		_iVolunteer.setExpandoBridgeAttributes(serviceContext);
	}

	/**
	* Sets the group ID of this i volunteer.
	*
	* @param groupId the group ID of this i volunteer
	*/
	@Override
	public void setGroupId(long groupId) {
		_iVolunteer.setGroupId(groupId);
	}

	/**
	* Sets the message of this i volunteer.
	*
	* @param message the message of this i volunteer
	*/
	@Override
	public void setMessage(String message) {
		_iVolunteer.setMessage(message);
	}

	/**
	* Sets the modified date of this i volunteer.
	*
	* @param modifiedDate the modified date of this i volunteer
	*/
	@Override
	public void setModifiedDate(Date modifiedDate) {
		_iVolunteer.setModifiedDate(modifiedDate);
	}

	/**
	* Sets the name of this i volunteer.
	*
	* @param name the name of this i volunteer
	*/
	@Override
	public void setName(String name) {
		_iVolunteer.setName(name);
	}

	@Override
	public void setNew(boolean n) {
		_iVolunteer.setNew(n);
	}

	/**
	* Sets the phone number of this i volunteer.
	*
	* @param phoneNumber the phone number of this i volunteer
	*/
	@Override
	public void setPhoneNumber(String phoneNumber) {
		_iVolunteer.setPhoneNumber(phoneNumber);
	}

	/**
	* Sets the primary key of this i volunteer.
	*
	* @param primaryKey the primary key of this i volunteer
	*/
	@Override
	public void setPrimaryKey(long primaryKey) {
		_iVolunteer.setPrimaryKey(primaryKey);
	}

	@Override
	public void setPrimaryKeyObj(Serializable primaryKeyObj) {
		_iVolunteer.setPrimaryKeyObj(primaryKeyObj);
	}

	/**
	* Sets the subject of this i volunteer.
	*
	* @param subject the subject of this i volunteer
	*/
	@Override
	public void setSubject(String subject) {
		_iVolunteer.setSubject(subject);
	}

	/**
	* Sets the user ID of this i volunteer.
	*
	* @param userId the user ID of this i volunteer
	*/
	@Override
	public void setUserId(long userId) {
		_iVolunteer.setUserId(userId);
	}

	/**
	* Sets the user uuid of this i volunteer.
	*
	* @param userUuid the user uuid of this i volunteer
	*/
	@Override
	public void setUserUuid(String userUuid) {
		_iVolunteer.setUserUuid(userUuid);
	}

	/**
	* Sets the uuid of this i volunteer.
	*
	* @param uuid the uuid of this i volunteer
	*/
	@Override
	public void setUuid(String uuid) {
		_iVolunteer.setUuid(uuid);
	}

	/**
	* Sets the volunteer ID of this i volunteer.
	*
	* @param volunteerId the volunteer ID of this i volunteer
	*/
	@Override
	public void setVolunteerId(long volunteerId) {
		_iVolunteer.setVolunteerId(volunteerId);
	}

	@Override
	public com.liferay.portal.kernel.model.CacheModel<IVolunteer> toCacheModel() {
		return _iVolunteer.toCacheModel();
	}

	@Override
	public IVolunteer toEscapedModel() {
		return new IVolunteerWrapper(_iVolunteer.toEscapedModel());
	}

	@Override
	public String toString() {
		return _iVolunteer.toString();
	}

	@Override
	public IVolunteer toUnescapedModel() {
		return new IVolunteerWrapper(_iVolunteer.toUnescapedModel());
	}

	@Override
	public String toXmlString() {
		return _iVolunteer.toXmlString();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof IVolunteerWrapper)) {
			return false;
		}

		IVolunteerWrapper iVolunteerWrapper = (IVolunteerWrapper)obj;

		if (Objects.equals(_iVolunteer, iVolunteerWrapper._iVolunteer)) {
			return true;
		}

		return false;
	}

	@Override
	public StagedModelType getStagedModelType() {
		return _iVolunteer.getStagedModelType();
	}

	@Override
	public IVolunteer getWrappedModel() {
		return _iVolunteer;
	}

	@Override
	public boolean isEntityCacheEnabled() {
		return _iVolunteer.isEntityCacheEnabled();
	}

	@Override
	public boolean isFinderCacheEnabled() {
		return _iVolunteer.isFinderCacheEnabled();
	}

	@Override
	public void resetOriginalValues() {
		_iVolunteer.resetOriginalValues();
	}

	private final IVolunteer _iVolunteer;
}