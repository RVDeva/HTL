/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.al.services.aliVolunteer.service.persistence;

import aQute.bnd.annotation.ProviderType;

import com.al.services.aliVolunteer.model.IVolunteer;

import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.service.ServiceContext;
import com.liferay.portal.kernel.util.OrderByComparator;

import org.osgi.framework.Bundle;
import org.osgi.framework.FrameworkUtil;

import org.osgi.util.tracker.ServiceTracker;

import java.util.List;

/**
 * The persistence utility for the i volunteer service. This utility wraps {@link com.al.services.aliVolunteer.service.persistence.impl.IVolunteerPersistenceImpl} and provides direct access to the database for CRUD operations. This utility should only be used by the service layer, as it must operate within a transaction. Never access this utility in a JSP, controller, model, or other front-end class.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see IVolunteerPersistence
 * @see com.al.services.aliVolunteer.service.persistence.impl.IVolunteerPersistenceImpl
 * @generated
 */
@ProviderType
public class IVolunteerUtil {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify this class directly. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache()
	 */
	public static void clearCache() {
		getPersistence().clearCache();
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#clearCache(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static void clearCache(IVolunteer iVolunteer) {
		getPersistence().clearCache(iVolunteer);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#countWithDynamicQuery(DynamicQuery)
	 */
	public static long countWithDynamicQuery(DynamicQuery dynamicQuery) {
		return getPersistence().countWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery)
	 */
	public static List<IVolunteer> findWithDynamicQuery(
		DynamicQuery dynamicQuery) {
		return getPersistence().findWithDynamicQuery(dynamicQuery);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int)
	 */
	public static List<IVolunteer> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end) {
		return getPersistence().findWithDynamicQuery(dynamicQuery, start, end);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#findWithDynamicQuery(DynamicQuery, int, int, OrderByComparator)
	 */
	public static List<IVolunteer> findWithDynamicQuery(
		DynamicQuery dynamicQuery, int start, int end,
		OrderByComparator<IVolunteer> orderByComparator) {
		return getPersistence()
				   .findWithDynamicQuery(dynamicQuery, start, end,
			orderByComparator);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel)
	 */
	public static IVolunteer update(IVolunteer iVolunteer) {
		return getPersistence().update(iVolunteer);
	}

	/**
	 * @see com.liferay.portal.kernel.service.persistence.BasePersistence#update(com.liferay.portal.kernel.model.BaseModel, ServiceContext)
	 */
	public static IVolunteer update(IVolunteer iVolunteer,
		ServiceContext serviceContext) {
		return getPersistence().update(iVolunteer, serviceContext);
	}

	/**
	* Returns all the i volunteers where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the matching i volunteers
	*/
	public static List<IVolunteer> findByUuid(String uuid) {
		return getPersistence().findByUuid(uuid);
	}

	/**
	* Returns a range of all the i volunteers where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link IVolunteerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of i volunteers
	* @param end the upper bound of the range of i volunteers (not inclusive)
	* @return the range of matching i volunteers
	*/
	public static List<IVolunteer> findByUuid(String uuid, int start, int end) {
		return getPersistence().findByUuid(uuid, start, end);
	}

	/**
	* Returns an ordered range of all the i volunteers where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link IVolunteerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of i volunteers
	* @param end the upper bound of the range of i volunteers (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching i volunteers
	*/
	public static List<IVolunteer> findByUuid(String uuid, int start, int end,
		OrderByComparator<IVolunteer> orderByComparator) {
		return getPersistence().findByUuid(uuid, start, end, orderByComparator);
	}

	/**
	* Returns an ordered range of all the i volunteers where uuid = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link IVolunteerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param start the lower bound of the range of i volunteers
	* @param end the upper bound of the range of i volunteers (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of matching i volunteers
	*/
	public static List<IVolunteer> findByUuid(String uuid, int start, int end,
		OrderByComparator<IVolunteer> orderByComparator,
		boolean retrieveFromCache) {
		return getPersistence()
				   .findByUuid(uuid, start, end, orderByComparator,
			retrieveFromCache);
	}

	/**
	* Returns the first i volunteer in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching i volunteer
	* @throws NoSuchIVolunteerException if a matching i volunteer could not be found
	*/
	public static IVolunteer findByUuid_First(String uuid,
		OrderByComparator<IVolunteer> orderByComparator)
		throws com.al.services.aliVolunteer.exception.NoSuchIVolunteerException {
		return getPersistence().findByUuid_First(uuid, orderByComparator);
	}

	/**
	* Returns the first i volunteer in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching i volunteer, or <code>null</code> if a matching i volunteer could not be found
	*/
	public static IVolunteer fetchByUuid_First(String uuid,
		OrderByComparator<IVolunteer> orderByComparator) {
		return getPersistence().fetchByUuid_First(uuid, orderByComparator);
	}

	/**
	* Returns the last i volunteer in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching i volunteer
	* @throws NoSuchIVolunteerException if a matching i volunteer could not be found
	*/
	public static IVolunteer findByUuid_Last(String uuid,
		OrderByComparator<IVolunteer> orderByComparator)
		throws com.al.services.aliVolunteer.exception.NoSuchIVolunteerException {
		return getPersistence().findByUuid_Last(uuid, orderByComparator);
	}

	/**
	* Returns the last i volunteer in the ordered set where uuid = &#63;.
	*
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching i volunteer, or <code>null</code> if a matching i volunteer could not be found
	*/
	public static IVolunteer fetchByUuid_Last(String uuid,
		OrderByComparator<IVolunteer> orderByComparator) {
		return getPersistence().fetchByUuid_Last(uuid, orderByComparator);
	}

	/**
	* Returns the i volunteers before and after the current i volunteer in the ordered set where uuid = &#63;.
	*
	* @param volunteerId the primary key of the current i volunteer
	* @param uuid the uuid
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next i volunteer
	* @throws NoSuchIVolunteerException if a i volunteer with the primary key could not be found
	*/
	public static IVolunteer[] findByUuid_PrevAndNext(long volunteerId,
		String uuid, OrderByComparator<IVolunteer> orderByComparator)
		throws com.al.services.aliVolunteer.exception.NoSuchIVolunteerException {
		return getPersistence()
				   .findByUuid_PrevAndNext(volunteerId, uuid, orderByComparator);
	}

	/**
	* Removes all the i volunteers where uuid = &#63; from the database.
	*
	* @param uuid the uuid
	*/
	public static void removeByUuid(String uuid) {
		getPersistence().removeByUuid(uuid);
	}

	/**
	* Returns the number of i volunteers where uuid = &#63;.
	*
	* @param uuid the uuid
	* @return the number of matching i volunteers
	*/
	public static int countByUuid(String uuid) {
		return getPersistence().countByUuid(uuid);
	}

	/**
	* Returns the i volunteer where uuid = &#63; and groupId = &#63; or throws a {@link NoSuchIVolunteerException} if it could not be found.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching i volunteer
	* @throws NoSuchIVolunteerException if a matching i volunteer could not be found
	*/
	public static IVolunteer findByUUID_G(String uuid, long groupId)
		throws com.al.services.aliVolunteer.exception.NoSuchIVolunteerException {
		return getPersistence().findByUUID_G(uuid, groupId);
	}

	/**
	* Returns the i volunteer where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found. Uses the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the matching i volunteer, or <code>null</code> if a matching i volunteer could not be found
	*/
	public static IVolunteer fetchByUUID_G(String uuid, long groupId) {
		return getPersistence().fetchByUUID_G(uuid, groupId);
	}

	/**
	* Returns the i volunteer where uuid = &#63; and groupId = &#63; or returns <code>null</code> if it could not be found, optionally using the finder cache.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the matching i volunteer, or <code>null</code> if a matching i volunteer could not be found
	*/
	public static IVolunteer fetchByUUID_G(String uuid, long groupId,
		boolean retrieveFromCache) {
		return getPersistence().fetchByUUID_G(uuid, groupId, retrieveFromCache);
	}

	/**
	* Removes the i volunteer where uuid = &#63; and groupId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the i volunteer that was removed
	*/
	public static IVolunteer removeByUUID_G(String uuid, long groupId)
		throws com.al.services.aliVolunteer.exception.NoSuchIVolunteerException {
		return getPersistence().removeByUUID_G(uuid, groupId);
	}

	/**
	* Returns the number of i volunteers where uuid = &#63; and groupId = &#63;.
	*
	* @param uuid the uuid
	* @param groupId the group ID
	* @return the number of matching i volunteers
	*/
	public static int countByUUID_G(String uuid, long groupId) {
		return getPersistence().countByUUID_G(uuid, groupId);
	}

	/**
	* Returns all the i volunteers where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the matching i volunteers
	*/
	public static List<IVolunteer> findByUuid_C(String uuid, long companyId) {
		return getPersistence().findByUuid_C(uuid, companyId);
	}

	/**
	* Returns a range of all the i volunteers where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link IVolunteerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of i volunteers
	* @param end the upper bound of the range of i volunteers (not inclusive)
	* @return the range of matching i volunteers
	*/
	public static List<IVolunteer> findByUuid_C(String uuid, long companyId,
		int start, int end) {
		return getPersistence().findByUuid_C(uuid, companyId, start, end);
	}

	/**
	* Returns an ordered range of all the i volunteers where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link IVolunteerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of i volunteers
	* @param end the upper bound of the range of i volunteers (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching i volunteers
	*/
	public static List<IVolunteer> findByUuid_C(String uuid, long companyId,
		int start, int end, OrderByComparator<IVolunteer> orderByComparator) {
		return getPersistence()
				   .findByUuid_C(uuid, companyId, start, end, orderByComparator);
	}

	/**
	* Returns an ordered range of all the i volunteers where uuid = &#63; and companyId = &#63;.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link IVolunteerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param start the lower bound of the range of i volunteers
	* @param end the upper bound of the range of i volunteers (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of matching i volunteers
	*/
	public static List<IVolunteer> findByUuid_C(String uuid, long companyId,
		int start, int end, OrderByComparator<IVolunteer> orderByComparator,
		boolean retrieveFromCache) {
		return getPersistence()
				   .findByUuid_C(uuid, companyId, start, end,
			orderByComparator, retrieveFromCache);
	}

	/**
	* Returns the first i volunteer in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching i volunteer
	* @throws NoSuchIVolunteerException if a matching i volunteer could not be found
	*/
	public static IVolunteer findByUuid_C_First(String uuid, long companyId,
		OrderByComparator<IVolunteer> orderByComparator)
		throws com.al.services.aliVolunteer.exception.NoSuchIVolunteerException {
		return getPersistence()
				   .findByUuid_C_First(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the first i volunteer in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the first matching i volunteer, or <code>null</code> if a matching i volunteer could not be found
	*/
	public static IVolunteer fetchByUuid_C_First(String uuid, long companyId,
		OrderByComparator<IVolunteer> orderByComparator) {
		return getPersistence()
				   .fetchByUuid_C_First(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the last i volunteer in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching i volunteer
	* @throws NoSuchIVolunteerException if a matching i volunteer could not be found
	*/
	public static IVolunteer findByUuid_C_Last(String uuid, long companyId,
		OrderByComparator<IVolunteer> orderByComparator)
		throws com.al.services.aliVolunteer.exception.NoSuchIVolunteerException {
		return getPersistence()
				   .findByUuid_C_Last(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the last i volunteer in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the last matching i volunteer, or <code>null</code> if a matching i volunteer could not be found
	*/
	public static IVolunteer fetchByUuid_C_Last(String uuid, long companyId,
		OrderByComparator<IVolunteer> orderByComparator) {
		return getPersistence()
				   .fetchByUuid_C_Last(uuid, companyId, orderByComparator);
	}

	/**
	* Returns the i volunteers before and after the current i volunteer in the ordered set where uuid = &#63; and companyId = &#63;.
	*
	* @param volunteerId the primary key of the current i volunteer
	* @param uuid the uuid
	* @param companyId the company ID
	* @param orderByComparator the comparator to order the set by (optionally <code>null</code>)
	* @return the previous, current, and next i volunteer
	* @throws NoSuchIVolunteerException if a i volunteer with the primary key could not be found
	*/
	public static IVolunteer[] findByUuid_C_PrevAndNext(long volunteerId,
		String uuid, long companyId,
		OrderByComparator<IVolunteer> orderByComparator)
		throws com.al.services.aliVolunteer.exception.NoSuchIVolunteerException {
		return getPersistence()
				   .findByUuid_C_PrevAndNext(volunteerId, uuid, companyId,
			orderByComparator);
	}

	/**
	* Removes all the i volunteers where uuid = &#63; and companyId = &#63; from the database.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	*/
	public static void removeByUuid_C(String uuid, long companyId) {
		getPersistence().removeByUuid_C(uuid, companyId);
	}

	/**
	* Returns the number of i volunteers where uuid = &#63; and companyId = &#63;.
	*
	* @param uuid the uuid
	* @param companyId the company ID
	* @return the number of matching i volunteers
	*/
	public static int countByUuid_C(String uuid, long companyId) {
		return getPersistence().countByUuid_C(uuid, companyId);
	}

	/**
	* Caches the i volunteer in the entity cache if it is enabled.
	*
	* @param iVolunteer the i volunteer
	*/
	public static void cacheResult(IVolunteer iVolunteer) {
		getPersistence().cacheResult(iVolunteer);
	}

	/**
	* Caches the i volunteers in the entity cache if it is enabled.
	*
	* @param iVolunteers the i volunteers
	*/
	public static void cacheResult(List<IVolunteer> iVolunteers) {
		getPersistence().cacheResult(iVolunteers);
	}

	/**
	* Creates a new i volunteer with the primary key. Does not add the i volunteer to the database.
	*
	* @param volunteerId the primary key for the new i volunteer
	* @return the new i volunteer
	*/
	public static IVolunteer create(long volunteerId) {
		return getPersistence().create(volunteerId);
	}

	/**
	* Removes the i volunteer with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param volunteerId the primary key of the i volunteer
	* @return the i volunteer that was removed
	* @throws NoSuchIVolunteerException if a i volunteer with the primary key could not be found
	*/
	public static IVolunteer remove(long volunteerId)
		throws com.al.services.aliVolunteer.exception.NoSuchIVolunteerException {
		return getPersistence().remove(volunteerId);
	}

	public static IVolunteer updateImpl(IVolunteer iVolunteer) {
		return getPersistence().updateImpl(iVolunteer);
	}

	/**
	* Returns the i volunteer with the primary key or throws a {@link NoSuchIVolunteerException} if it could not be found.
	*
	* @param volunteerId the primary key of the i volunteer
	* @return the i volunteer
	* @throws NoSuchIVolunteerException if a i volunteer with the primary key could not be found
	*/
	public static IVolunteer findByPrimaryKey(long volunteerId)
		throws com.al.services.aliVolunteer.exception.NoSuchIVolunteerException {
		return getPersistence().findByPrimaryKey(volunteerId);
	}

	/**
	* Returns the i volunteer with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param volunteerId the primary key of the i volunteer
	* @return the i volunteer, or <code>null</code> if a i volunteer with the primary key could not be found
	*/
	public static IVolunteer fetchByPrimaryKey(long volunteerId) {
		return getPersistence().fetchByPrimaryKey(volunteerId);
	}

	public static java.util.Map<java.io.Serializable, IVolunteer> fetchByPrimaryKeys(
		java.util.Set<java.io.Serializable> primaryKeys) {
		return getPersistence().fetchByPrimaryKeys(primaryKeys);
	}

	/**
	* Returns all the i volunteers.
	*
	* @return the i volunteers
	*/
	public static List<IVolunteer> findAll() {
		return getPersistence().findAll();
	}

	/**
	* Returns a range of all the i volunteers.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link IVolunteerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of i volunteers
	* @param end the upper bound of the range of i volunteers (not inclusive)
	* @return the range of i volunteers
	*/
	public static List<IVolunteer> findAll(int start, int end) {
		return getPersistence().findAll(start, end);
	}

	/**
	* Returns an ordered range of all the i volunteers.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link IVolunteerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of i volunteers
	* @param end the upper bound of the range of i volunteers (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of i volunteers
	*/
	public static List<IVolunteer> findAll(int start, int end,
		OrderByComparator<IVolunteer> orderByComparator) {
		return getPersistence().findAll(start, end, orderByComparator);
	}

	/**
	* Returns an ordered range of all the i volunteers.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link IVolunteerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of i volunteers
	* @param end the upper bound of the range of i volunteers (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of i volunteers
	*/
	public static List<IVolunteer> findAll(int start, int end,
		OrderByComparator<IVolunteer> orderByComparator,
		boolean retrieveFromCache) {
		return getPersistence()
				   .findAll(start, end, orderByComparator, retrieveFromCache);
	}

	/**
	* Removes all the i volunteers from the database.
	*/
	public static void removeAll() {
		getPersistence().removeAll();
	}

	/**
	* Returns the number of i volunteers.
	*
	* @return the number of i volunteers
	*/
	public static int countAll() {
		return getPersistence().countAll();
	}

	public static java.util.Set<String> getBadColumnNames() {
		return getPersistence().getBadColumnNames();
	}

	public static IVolunteerPersistence getPersistence() {
		return _serviceTracker.getService();
	}

	private static ServiceTracker<IVolunteerPersistence, IVolunteerPersistence> _serviceTracker;

	static {
		Bundle bundle = FrameworkUtil.getBundle(IVolunteerPersistence.class);

		ServiceTracker<IVolunteerPersistence, IVolunteerPersistence> serviceTracker =
			new ServiceTracker<IVolunteerPersistence, IVolunteerPersistence>(bundle.getBundleContext(),
				IVolunteerPersistence.class, null);

		serviceTracker.open();

		_serviceTracker = serviceTracker;
	}
}