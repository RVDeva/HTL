/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.al.services.aliVolunteer.service;

import aQute.bnd.annotation.ProviderType;

import com.al.services.aliVolunteer.model.IVolunteer;

import com.liferay.exportimport.kernel.lar.PortletDataContext;

import com.liferay.portal.kernel.dao.orm.ActionableDynamicQuery;
import com.liferay.portal.kernel.dao.orm.DynamicQuery;
import com.liferay.portal.kernel.dao.orm.ExportActionableDynamicQuery;
import com.liferay.portal.kernel.dao.orm.IndexableActionableDynamicQuery;
import com.liferay.portal.kernel.dao.orm.Projection;
import com.liferay.portal.kernel.exception.PortalException;
import com.liferay.portal.kernel.exception.SystemException;
import com.liferay.portal.kernel.model.PersistedModel;
import com.liferay.portal.kernel.search.Indexable;
import com.liferay.portal.kernel.search.IndexableType;
import com.liferay.portal.kernel.service.BaseLocalService;
import com.liferay.portal.kernel.service.PersistedModelLocalService;
import com.liferay.portal.kernel.transaction.Isolation;
import com.liferay.portal.kernel.transaction.Propagation;
import com.liferay.portal.kernel.transaction.Transactional;
import com.liferay.portal.kernel.util.OrderByComparator;

import java.io.Serializable;

import java.util.List;

/**
 * Provides the local service interface for IVolunteer. Methods of this
 * service will not have security checks based on the propagated JAAS
 * credentials because this service can only be accessed from within the same
 * VM.
 *
 * @author Brian Wing Shun Chan
 * @see IVolunteerLocalServiceUtil
 * @see com.al.services.aliVolunteer.service.base.IVolunteerLocalServiceBaseImpl
 * @see com.al.services.aliVolunteer.service.impl.IVolunteerLocalServiceImpl
 * @generated
 */
@ProviderType
@Transactional(isolation = Isolation.PORTAL, rollbackFor =  {
	PortalException.class, SystemException.class})
public interface IVolunteerLocalService extends BaseLocalService,
	PersistedModelLocalService {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link IVolunteerLocalServiceUtil} to access the i volunteer local service. Add custom service methods to {@link com.al.services.aliVolunteer.service.impl.IVolunteerLocalServiceImpl} and rerun ServiceBuilder to automatically copy the method declarations to this interface.
	 */

	/**
	* Adds the i volunteer to the database. Also notifies the appropriate model listeners.
	*
	* @param iVolunteer the i volunteer
	* @return the i volunteer that was added
	*/
	@Indexable(type = IndexableType.REINDEX)
	public IVolunteer addIVolunteer(IVolunteer iVolunteer);

	/**
	* This method is used to create iVolunteer
	*/
	public IVolunteer create(long volunteerId, long groupId, long companyId,
		long userId, String name, String email, String phoneNumber,
		String subject, String address, String message);

	/**
	* Creates a new i volunteer with the primary key. Does not add the i volunteer to the database.
	*
	* @param volunteerId the primary key for the new i volunteer
	* @return the new i volunteer
	*/
	@Transactional(enabled = false)
	public IVolunteer createIVolunteer(long volunteerId);

	/**
	* Deletes the i volunteer from the database. Also notifies the appropriate model listeners.
	*
	* @param iVolunteer the i volunteer
	* @return the i volunteer that was removed
	*/
	@Indexable(type = IndexableType.DELETE)
	public IVolunteer deleteIVolunteer(IVolunteer iVolunteer);

	/**
	* Deletes the i volunteer with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param volunteerId the primary key of the i volunteer
	* @return the i volunteer that was removed
	* @throws PortalException if a i volunteer with the primary key could not be found
	*/
	@Indexable(type = IndexableType.DELETE)
	public IVolunteer deleteIVolunteer(long volunteerId)
		throws PortalException;

	/**
	* @throws PortalException
	*/
	@Override
	public PersistedModel deletePersistedModel(PersistedModel persistedModel)
		throws PortalException;

	public DynamicQuery dynamicQuery();

	/**
	* Performs a dynamic query on the database and returns the matching rows.
	*
	* @param dynamicQuery the dynamic query
	* @return the matching rows
	*/
	public <T> List<T> dynamicQuery(DynamicQuery dynamicQuery);

	/**
	* Performs a dynamic query on the database and returns a range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.al.services.aliVolunteer.model.impl.IVolunteerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @return the range of matching rows
	*/
	public <T> List<T> dynamicQuery(DynamicQuery dynamicQuery, int start,
		int end);

	/**
	* Performs a dynamic query on the database and returns an ordered range of the matching rows.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.al.services.aliVolunteer.model.impl.IVolunteerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param dynamicQuery the dynamic query
	* @param start the lower bound of the range of model instances
	* @param end the upper bound of the range of model instances (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of matching rows
	*/
	public <T> List<T> dynamicQuery(DynamicQuery dynamicQuery, int start,
		int end, OrderByComparator<T> orderByComparator);

	/**
	* Returns the number of rows matching the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @return the number of rows matching the dynamic query
	*/
	public long dynamicQueryCount(DynamicQuery dynamicQuery);

	/**
	* Returns the number of rows matching the dynamic query.
	*
	* @param dynamicQuery the dynamic query
	* @param projection the projection to apply to the query
	* @return the number of rows matching the dynamic query
	*/
	public long dynamicQueryCount(DynamicQuery dynamicQuery,
		Projection projection);

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public IVolunteer fetchIVolunteer(long volunteerId);

	/**
	* Returns the i volunteer matching the UUID and group.
	*
	* @param uuid the i volunteer's UUID
	* @param groupId the primary key of the group
	* @return the matching i volunteer, or <code>null</code> if a matching i volunteer could not be found
	*/
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public IVolunteer fetchIVolunteerByUuidAndGroupId(String uuid, long groupId);

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public ActionableDynamicQuery getActionableDynamicQuery();

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public ExportActionableDynamicQuery getExportActionableDynamicQuery(
		PortletDataContext portletDataContext);

	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public IndexableActionableDynamicQuery getIndexableActionableDynamicQuery();

	/**
	* Returns the i volunteer with the primary key.
	*
	* @param volunteerId the primary key of the i volunteer
	* @return the i volunteer
	* @throws PortalException if a i volunteer with the primary key could not be found
	*/
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public IVolunteer getIVolunteer(long volunteerId) throws PortalException;

	/**
	* Returns the i volunteer matching the UUID and group.
	*
	* @param uuid the i volunteer's UUID
	* @param groupId the primary key of the group
	* @return the matching i volunteer
	* @throws PortalException if a matching i volunteer could not be found
	*/
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public IVolunteer getIVolunteerByUuidAndGroupId(String uuid, long groupId)
		throws PortalException;

	/**
	* Returns a range of all the i volunteers.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link com.liferay.portal.kernel.dao.orm.QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link com.al.services.aliVolunteer.model.impl.IVolunteerModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of i volunteers
	* @param end the upper bound of the range of i volunteers (not inclusive)
	* @return the range of i volunteers
	*/
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<IVolunteer> getIVolunteers(int start, int end);

	/**
	* Returns all the i volunteers matching the UUID and company.
	*
	* @param uuid the UUID of the i volunteers
	* @param companyId the primary key of the company
	* @return the matching i volunteers, or an empty list if no matches were found
	*/
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<IVolunteer> getIVolunteersByUuidAndCompanyId(String uuid,
		long companyId);

	/**
	* Returns a range of i volunteers matching the UUID and company.
	*
	* @param uuid the UUID of the i volunteers
	* @param companyId the primary key of the company
	* @param start the lower bound of the range of i volunteers
	* @param end the upper bound of the range of i volunteers (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the range of matching i volunteers, or an empty list if no matches were found
	*/
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public List<IVolunteer> getIVolunteersByUuidAndCompanyId(String uuid,
		long companyId, int start, int end,
		OrderByComparator<IVolunteer> orderByComparator);

	/**
	* Returns the number of i volunteers.
	*
	* @return the number of i volunteers
	*/
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public int getIVolunteersCount();

	/**
	* Returns the OSGi service identifier.
	*
	* @return the OSGi service identifier
	*/
	public String getOSGiServiceIdentifier();

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
	public PersistedModel getPersistedModel(Serializable primaryKeyObj)
		throws PortalException;

	/**
	* Updates the i volunteer in the database or adds it if it does not yet exist. Also notifies the appropriate model listeners.
	*
	* @param iVolunteer the i volunteer
	* @return the i volunteer that was updated
	*/
	@Indexable(type = IndexableType.REINDEX)
	public IVolunteer updateIVolunteer(IVolunteer iVolunteer);
}