create index IX_7A69D04 on al_corpweb_IVolunteer (uuid_[$COLUMN_LENGTH:75$], companyId);
create unique index IX_B57A9486 on al_corpweb_IVolunteer (uuid_[$COLUMN_LENGTH:75$], groupId);