create table al_corpweb_IVolunteer (
	uuid_ VARCHAR(75) null,
	volunteerId LONG not null primary key,
	groupId LONG,
	companyId LONG,
	userId LONG,
	createDate DATE null,
	modifiedDate DATE null,
	name VARCHAR(75) null,
	email VARCHAR(75) null,
	phoneNumber VARCHAR(75) null,
	subject VARCHAR(75) null,
	address VARCHAR(75) null,
	message VARCHAR(75) null
);