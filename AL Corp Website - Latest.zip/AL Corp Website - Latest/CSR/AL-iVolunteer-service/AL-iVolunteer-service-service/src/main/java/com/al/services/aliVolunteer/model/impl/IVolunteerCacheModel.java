/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.al.services.aliVolunteer.model.impl;

import aQute.bnd.annotation.ProviderType;

import com.al.services.aliVolunteer.model.IVolunteer;

import com.liferay.portal.kernel.model.CacheModel;
import com.liferay.portal.kernel.util.HashUtil;
import com.liferay.portal.kernel.util.StringBundler;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import java.util.Date;

/**
 * The cache model class for representing IVolunteer in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @see IVolunteer
 * @generated
 */
@ProviderType
public class IVolunteerCacheModel implements CacheModel<IVolunteer>,
	Externalizable {
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}

		if (!(obj instanceof IVolunteerCacheModel)) {
			return false;
		}

		IVolunteerCacheModel iVolunteerCacheModel = (IVolunteerCacheModel)obj;

		if (volunteerId == iVolunteerCacheModel.volunteerId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, volunteerId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(27);

		sb.append("{uuid=");
		sb.append(uuid);
		sb.append(", volunteerId=");
		sb.append(volunteerId);
		sb.append(", groupId=");
		sb.append(groupId);
		sb.append(", companyId=");
		sb.append(companyId);
		sb.append(", userId=");
		sb.append(userId);
		sb.append(", createDate=");
		sb.append(createDate);
		sb.append(", modifiedDate=");
		sb.append(modifiedDate);
		sb.append(", name=");
		sb.append(name);
		sb.append(", email=");
		sb.append(email);
		sb.append(", phoneNumber=");
		sb.append(phoneNumber);
		sb.append(", subject=");
		sb.append(subject);
		sb.append(", address=");
		sb.append(address);
		sb.append(", message=");
		sb.append(message);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public IVolunteer toEntityModel() {
		IVolunteerImpl iVolunteerImpl = new IVolunteerImpl();

		if (uuid == null) {
			iVolunteerImpl.setUuid("");
		}
		else {
			iVolunteerImpl.setUuid(uuid);
		}

		iVolunteerImpl.setVolunteerId(volunteerId);
		iVolunteerImpl.setGroupId(groupId);
		iVolunteerImpl.setCompanyId(companyId);
		iVolunteerImpl.setUserId(userId);

		if (createDate == Long.MIN_VALUE) {
			iVolunteerImpl.setCreateDate(null);
		}
		else {
			iVolunteerImpl.setCreateDate(new Date(createDate));
		}

		if (modifiedDate == Long.MIN_VALUE) {
			iVolunteerImpl.setModifiedDate(null);
		}
		else {
			iVolunteerImpl.setModifiedDate(new Date(modifiedDate));
		}

		if (name == null) {
			iVolunteerImpl.setName("");
		}
		else {
			iVolunteerImpl.setName(name);
		}

		if (email == null) {
			iVolunteerImpl.setEmail("");
		}
		else {
			iVolunteerImpl.setEmail(email);
		}

		if (phoneNumber == null) {
			iVolunteerImpl.setPhoneNumber("");
		}
		else {
			iVolunteerImpl.setPhoneNumber(phoneNumber);
		}

		if (subject == null) {
			iVolunteerImpl.setSubject("");
		}
		else {
			iVolunteerImpl.setSubject(subject);
		}

		if (address == null) {
			iVolunteerImpl.setAddress("");
		}
		else {
			iVolunteerImpl.setAddress(address);
		}

		if (message == null) {
			iVolunteerImpl.setMessage("");
		}
		else {
			iVolunteerImpl.setMessage(message);
		}

		iVolunteerImpl.resetOriginalValues();

		return iVolunteerImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		uuid = objectInput.readUTF();

		volunteerId = objectInput.readLong();

		groupId = objectInput.readLong();

		companyId = objectInput.readLong();

		userId = objectInput.readLong();
		createDate = objectInput.readLong();
		modifiedDate = objectInput.readLong();
		name = objectInput.readUTF();
		email = objectInput.readUTF();
		phoneNumber = objectInput.readUTF();
		subject = objectInput.readUTF();
		address = objectInput.readUTF();
		message = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput)
		throws IOException {
		if (uuid == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(uuid);
		}

		objectOutput.writeLong(volunteerId);

		objectOutput.writeLong(groupId);

		objectOutput.writeLong(companyId);

		objectOutput.writeLong(userId);
		objectOutput.writeLong(createDate);
		objectOutput.writeLong(modifiedDate);

		if (name == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(name);
		}

		if (email == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(email);
		}

		if (phoneNumber == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(phoneNumber);
		}

		if (subject == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(subject);
		}

		if (address == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(address);
		}

		if (message == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(message);
		}
	}

	public String uuid;
	public long volunteerId;
	public long groupId;
	public long companyId;
	public long userId;
	public long createDate;
	public long modifiedDate;
	public String name;
	public String email;
	public String phoneNumber;
	public String subject;
	public String address;
	public String message;
}