/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.al.services.aliVolunteer.service.impl;

import com.al.services.aliVolunteer.model.IVolunteer;
import com.al.services.aliVolunteer.service.IVolunteerLocalServiceUtil;
import com.al.services.aliVolunteer.service.base.IVolunteerLocalServiceBaseImpl;
import com.liferay.counter.kernel.service.CounterLocalServiceUtil;

import java.util.Date;

/**
 * The implementation of the i volunteer local service.
 *
 * <p>
 * All custom service methods should be put in this class. Whenever methods are added, rerun ServiceBuilder to copy their definitions into the {@link com.al.services.aliVolunteer.service.IVolunteerLocalService} interface.
 *
 * <p>
 * This is a local service. Methods of this service will not have security checks based on the propagated JAAS credentials because this service can only be accessed from within the same VM.
 * </p>
 *
 * @author VasuDeva
 * @see IVolunteerLocalServiceBaseImpl
 * @see com.al.services.aliVolunteer.service.IVolunteerLocalServiceUtil
 */
public class IVolunteerLocalServiceImpl extends IVolunteerLocalServiceBaseImpl {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never reference this class directly. Always use {@link com.al.services.aliVolunteer.service.IVolunteerLocalServiceUtil} to access the i volunteer local service.
	 */
	
	/**
	 * This method is used to create iVolunteer
	 */
	public IVolunteer create(long volunteerId, long groupId, long companyId, long userId, String name, String email, String phoneNumber, 
			String subject, String address, String message) {
		
		System.out.println("---Inside create method---");
		IVolunteer iVolunteer = null;
		
		if(volunteerId > 0) {
			iVolunteer = IVolunteerLocalServiceUtil.fetchIVolunteer(volunteerId);
		} else {
			iVolunteer = IVolunteerLocalServiceUtil.createIVolunteer(CounterLocalServiceUtil.increment(IVolunteer.class.getName()));
			iVolunteer.setCreateDate(new Date());
		}
		
		iVolunteer.setGroupId(groupId);
		iVolunteer.setCompanyId(companyId);
		iVolunteer.setUserId(userId);
		iVolunteer.setName(name);
		iVolunteer.setEmail(email);
		iVolunteer.setPhoneNumber(phoneNumber);
		iVolunteer.setSubject(subject);
		iVolunteer.setAddress(address);
		iVolunteer.setMessage(message);
		
		return iVolunteerPersistence.update(iVolunteer);
		
	}
	
}