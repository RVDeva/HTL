package com.al.iVolunteer.web.portlet;

import com.al.iVolunteer.web.constants.ALIVolunteerWebPortletKeys;
import com.al.services.aliVolunteer.service.IVolunteerLocalServiceUtil;
import com.liferay.mail.kernel.model.MailMessage;
import com.liferay.mail.kernel.service.MailServiceUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.servlet.SessionMessages;
import com.liferay.portal.kernel.theme.ThemeDisplay;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.portal.kernel.util.WebKeys;

import javax.mail.internet.InternetAddress;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;

import org.osgi.service.component.annotations.Component;

/**
 * @author VasuDeva
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=AL-iVolunteer-Web Portlet",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + ALIVolunteerWebPortletKeys.ALIVolunteerWeb,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class ALIVolunteerWebPortlet extends MVCPortlet {
	
	public void addiVolunteer(ActionRequest actionRequest, ActionResponse actionResponse) {
		
		System.out.println("---Inside addiVolunteer method---");
		
		String name = ParamUtil.getString(actionRequest, "name");
		String email = ParamUtil.getString(actionRequest, "email");
		String phoneNumber = ParamUtil.getString(actionRequest, "phoneNumber");
		String subject = ParamUtil.getString(actionRequest, "subject");
		String address = ParamUtil.getString(actionRequest, "address");
		String message = ParamUtil.getString(actionRequest, "message");
		
		ThemeDisplay themDisplay = (ThemeDisplay)actionRequest.getAttribute(WebKeys.THEME_DISPLAY);
		long volunteerId = 0l;
		long groupId = themDisplay.getLayout().getGroupId();
		long companyId = themDisplay.getCompanyId();
		long userId = themDisplay.getUserId();
		
		System.out.println("Name : "+name);
		System.out.println("Email : "+email);
		System.out.println("Phone Number : "+phoneNumber);
		System.out.println("Subject : "+subject);
		System.out.println("Address : "+address);
		System.out.println("Message : "+message);
		System.out.println("GroupId : "+groupId);
		System.out.println("CompanyId : "+companyId);
		System.out.println("UserId : "+userId);
		
		try {
			InternetAddress sender = new InternetAddress();
			sender.setAddress("liferay.test@testdomain.com");
		
			InternetAddress receiver = new InternetAddress();
			receiver.setAddress("vasudevan.rengarajan@hindujatech.com");
		
			String body = "Hi " + name +", An Email has been sent to your mail ID.";
			System.out.println("Msg : "+body);
		
			MailMessage mailContent = new MailMessage();
		
			mailContent.setFrom(sender);
			mailContent.setTo(receiver);
			mailContent.setSubject(subject);
			mailContent.setBody(body);
			mailContent.setHTMLFormat(false);
		
			//Sending Mail
			//MailServiceUtil.sendEmail(mailContent);
			SessionMessages.add(actionRequest, "mail-send-success");
			//Adding to iVolunteer
			IVolunteerLocalServiceUtil.create(volunteerId, groupId, companyId, userId, name, email, phoneNumber, subject, address, message);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		actionResponse.setRenderParameter("jspPage", "/view.jsp");
		
	}
	
}