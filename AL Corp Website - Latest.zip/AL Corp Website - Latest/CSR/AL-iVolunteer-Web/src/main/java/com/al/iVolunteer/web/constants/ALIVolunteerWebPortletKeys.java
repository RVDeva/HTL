package com.al.iVolunteer.web.constants;

/**
 * @author 16690
 */
public class ALIVolunteerWebPortletKeys {

	public static final String ALIVolunteerWeb = "alivolunteerweb";

}